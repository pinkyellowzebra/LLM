import asyncio
import os
import logging
from utils.blob_utils import blob_storage_manager # 수정된 blob_utils.py에서 import

# 로깅 설정 (업로드 과정의 로그를 확인하기 위함)
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

async def upload_excel_to_analytics_folder():
    """
    로컬 Excel 파일을 Azure Blob Storage의 메인 컨테이너 내 'analyticsfiles' 폴더에 업로드합니다.
    """
    # --- 1. 로컬 파일 경로 설정 (★★ 중요: 이 부분을 실제 파일 경로로 변경해주세요 ★★)
    local_excel_file_path = "C:/Users/eunhee.hong/Desktop/메일 발신 로그.xlsx" 
    # 예시: "C:/Users/사용자이름/Downloads/20250616132257_메일 발신 로그.xlsx"
    # 또는 Linux/macOS: "/home/youruser/documents/20250616132257_메일 발신 로그.xlsx"

    # 파일이 존재하는지 확인
    if not os.path.exists(local_excel_file_path):
        logger.error(f"Error: Local file not found at '{local_excel_file_path}'. Please check the path.")
        print(f"오류: 로컬 파일 '{local_excel_file_path}'을(를) 찾을 수 없습니다. 경로를 확인해주세요.")
        return

    # Blob Storage에 업로드될 파일의 실제 이름 (폴더 경로 제외)
    original_filename = os.path.basename(local_excel_file_path) # "20250616132257_메일 발신 로그.xlsx"

    # Excel 파일의 Content-Type
    content_type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

    print(f"로컬 파일: {local_excel_file_path}")
    print(f"업로드될 원본 파일명: {original_filename}")
    print(f"Content-Type: {content_type}")
    print(f"대상 폴더: analyticsfiles (BLOB_FOLDER_FILES 설정 값)")

    try:
        # --- 2. BlobStorageManager 초기화 및 컨테이너 확인 ---
        # initialize_container()는 메인 컨테이너가 없으면 생성해줍니다.
        await blob_storage_manager.initialize_container() 
        logger.info("BlobStorageManager initialized and main container ensured.")

        # --- 3. 로컬 파일 내용 읽기 ---
        with open(local_excel_file_path, "rb") as f:
            file_content = f.read()
        
        print(f"파일 내용 읽기 완료. 크기: {len(file_content)} bytes")

        # --- 4. Blob Storage에 파일 업로드 호출 ---
        # blob_utils.py의 upload_file 메서드는 BLOB_FOLDER_FILES를 사용하여 폴더 경로를 자동으로 추가합니다.
        # 따라서 여기서는 BLOB_FOLDER_FILES가 'analyticsfiles'로 설정되어 있다고 가정합니다.
        # user_id=None으로 두면 'analyticsfiles' 바로 아래에 업로드됩니다.
        print("Blob Storage에 파일 업로드 중...")
        upload_result = await blob_storage_manager.upload_file(
            file_content=file_content,
            filename=original_filename, # 파일명만 전달
            content_type=content_type,
            user_id=None # 'analyticsfiles' 폴더 바로 아래에 업로드 (사용자별 하위 폴더 없음)
        )

        if upload_result:
            print("\n--- 파일 업로드 성공! ---")
            print(f"업로드된 Blob 이름: {upload_result['blob_name']}")
            print(f"Blob URL: {upload_result['blob_url']}")
            logger.info(f"File uploaded successfully to: {upload_result['blob_url']}")
        else:
            print("\n--- 파일 업로드 실패 ---")
            logger.error("File upload failed, result was None.")

    except Exception as e:
        logger.error(f"An error occurred during file upload: {e}", exc_info=True)
        print(f"\n파일 업로드 중 오류 발생: {e}")

if __name__ == "__main__":
    # 비동기 함수 실행
    asyncio.run(upload_excel_to_analytics_folder())