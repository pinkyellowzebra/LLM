import logging
import os
import time
import psutil
from fastapi import FastAPI, Request, HTTPException, Depends
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from starlette.middleware.base import BaseHTTPMiddleware
from contextlib import asynccontextmanager
from typing import Optional, Dict, Any

# ---  로깅 설정 시작  ---
# settings.py에서 DEBUG_MODE를 가져옵니다. (settings.py에서 이미 load_dotenv()가 호출됩니다)
from config.settings import DEBUG_MODE 

# 단일 logging.basicConfig() 호출: DEBUG_MODE에 따라 레벨을 설정합니다.
log_level = logging.DEBUG if DEBUG_MODE else logging.INFO
logging.basicConfig(
    level=log_level,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
)

# OpenAI 및 httpx 라이브러리의 DEBUG 로깅 활성화 (basicConfig 이후에 설정)
logging.getLogger("openai").setLevel(logging.DEBUG)
logging.getLogger("httpx").setLevel(logging.DEBUG)

# 메인 로거 인스턴스를 가져옵니다. (basicConfig 호출 이후에)
logger = logging.getLogger(__name__)
logger.info(f"DEBUG_MODE is set to: {DEBUG_MODE}") # DEBUG_MODE 값 확인용 로그
# ---  로깅 설정 끝  ---


# Azure OpenAI 클라이언트 및 기타 모듈 임포트 (로깅 설정 이후)
from openai import AzureOpenAI

from config.settings import SERVER_HOST, SERVER_PORT, MAX_REQUESTS_PER_MINUTE
from config.settings import AZURE_OPENAI_API_KEY, AZURE_OPENAI_ENDPOINT, AZURE_OPENAI_API_VERSION, AZURE_OPENAI_DEPLOYMENT_NAME, AZURE_OPENAI_ASSISTANT_ID
from api.routes import chat_routes, file_routes, user_routes
from service.chat_service import ChatService
from api.deps import set_global_chat_service_instance, get_chat_service
from utils.blob_utils import blob_storage_manager


@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    FastAPI 애플리케이션의 시작 및 종료 이벤트를 처리하고,
    ChatService 인스턴스를 초기화합니다.
    """
    logger.info("Application startup event triggered.")
    logger.info(f"Loaded AZURE_OPENAI_API_VERSION: {AZURE_OPENAI_API_VERSION}") # API 버전 로깅
    logger.info(f"Loaded AZURE_OPENAI_ENDPOINT: {AZURE_OPENAI_ENDPOINT}") # 엔드포인트 로깅

    # Blob Storage 컨테이너 초기화
    try:
        await blob_storage_manager.initialize_container()
        logger.info("Blob Storage Container initialized successfully.")
    except Exception as e:
        logger.critical(f"FATAL: Failed to initialize Blob Storage Container: {e}", exc_info=True)
        raise RuntimeError(f"Failed to initialize Blob Storage Container: {e}")

    # Azure OpenAI 클라이언트 초기화
    # 환경 변수가 제대로 로드되었는지 최종 확인
    if not AZURE_OPENAI_API_KEY or not AZURE_OPENAI_ENDPOINT or not AZURE_OPENAI_API_VERSION:
        logger.critical("FATAL: One or more Azure OpenAI configuration variables (KEY, ENDPOINT, API_VERSION) are missing. Check your .env and settings.py.")
        raise RuntimeError("Azure OpenAI configuration missing.")

    client = AzureOpenAI(
        api_key=AZURE_OPENAI_API_KEY,
        api_version=AZURE_OPENAI_API_VERSION,
        azure_endpoint=AZURE_OPENAI_ENDPOINT
    )

    assistant_id_to_use: str

    if not AZURE_OPENAI_DEPLOYMENT_NAME:
        logger.critical("FATAL: AZURE_OPENAI_DEPLOYMENT_NAME 환경 변수가 설정되지 않았습니다. Assistant를 생성하거나 유효성을 검사할 수 없습니다.")
        raise RuntimeError("AZURE_OPENAI_DEPLOYMENT_NAME environment variable is not set. Cannot initialize Assistant.")

    if AZURE_OPENAI_ASSISTANT_ID:
        assistant_id_to_use = AZURE_OPENAI_ASSISTANT_ID
        logger.info(f"Using pre-configured Assistant ID: {assistant_id_to_use}")
        try:
            client.beta.assistants.retrieve(assistant_id_to_use)
            logger.info(f"Pre-configured Assistant ID '{assistant_id_to_use}' is valid.")
        except Exception as e:
            logger.error(f"Pre-configured Assistant ID '{assistant_id_to_use}' is invalid or not found. Attempting to create a new one. Error: {e}", exc_info=True)
            try:
                assistant = client.beta.assistants.create(
                    name="Data Analysis Assistant",
                    instructions="You are a data analysis assistant. Analyze the provided data files and answer questions about them. Generate visualizations when appropriate.",
                    model=AZURE_OPENAI_DEPLOYMENT_NAME,
                    tools=[{"type": "code_interpreter"}]
                )
                assistant_id_to_use = assistant.id
                logger.info(f"New Assistant created with ID: {assistant_id_to_use} due to invalid pre-configured ID.")
            except Exception as create_e:
                logger.critical(f"FATAL: Failed to create new Azure OpenAI Assistant after pre-configured ID failed: {create_e}", exc_info=True)
                raise RuntimeError(f"Failed to initialize Azure OpenAI Assistant: {create_e}")
    else:
        logger.info("No pre-configured Assistant ID found. Creating a new Assistant...")
        try:
            assistant = client.beta.assistants.create(
                name="Data Analysis Assistant",
                instructions="You are a data analysis assistant. Analyze the provided data files and answer questions about them. Generate visualizations when appropriate.",
                model=AZURE_OPENAI_DEPLOYMENT_NAME,
                tools=[{"type": "code_interpreter"}]
            )
            assistant_id_to_use = assistant.id
            logger.info(f"New Assistant created with ID: {assistant_id_to_use}")
        except Exception as e:
            logger.critical(f"FATAL: Failed to create Azure OpenAI Assistant on startup: {e}", exc_info=True)
            raise RuntimeError(f"Failed to initialize Azure OpenAI Assistant: {e}")

    # ChatService 인스턴스를 단 한 번만 생성하고 api/deps.py에 설정
    initialized_chat_service = ChatService(assistant_id=assistant_id_to_use)
    set_global_chat_service_instance(initialized_chat_service)
    logger.info("ChatService initialized successfully at application startup.")

    yield # 애플리케이션 실행

    logger.info("Application shutting down...")

# Create the FastAPI app with lifespan management
app = FastAPI(
    title="Analytics API",
    description="API for data analytics using Azure OpenAI",
    version="1.0.0",
    docs_url="/api/docs",
    redoc_url="/api/redoc",
    openapi_url="/api/openapi.json",
    lifespan=lifespan,
)
# Include routers
app.include_router(file_routes.router)
app.include_router(chat_routes.router)
app.include_router(user_routes.router, prefix="/api/users", tags=["users"])


# --- 미들웨어 설정 ---
class TimingMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        start_time = time.time()
        response = await call_next(request)
        process_time = time.time() - start_time
        response.headers["X-Process-Time"] = str(process_time)
        
        # INFO 레벨이 활성화되어 있을 때 모든 요청에 대한 로그를 남깁니다.
        if logger.isEnabledFor(logging.INFO):
            logger.info(f"Request: {request.method} {request.url.path} took {process_time:.2f}s")
        if process_time > 1.0: # 요청 처리 시간이 1초를 초과하면 WARNING 로그
            logger.warning(f"Slow request: {request.method} {request.url.path} took {process_time:.2f}s")
        
        return response

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["*"],
    expose_headers=["X-Process-Time", "Content-Disposition"],
    max_age=600,
)

app.add_middleware(
    TrustedHostMiddleware, allowed_hosts=["*"]
)

app.add_middleware(TimingMiddleware)

from fastapi.security import HTTPBearer
app.swagger_ui_init_oauth = None


# --- 정적 파일 및 템플릿 설정 ---
os.makedirs("static", exist_ok=True)
app.mount("/static", StaticFiles(directory="static"), name="static")

templates = Jinja2Templates(directory="templates")
os.makedirs("templates", exist_ok=True)

# --- 전역 예외 핸들러 ---
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    if isinstance(exc, HTTPException):
        if exc.status_code >= 400:
            logger.error(f"HTTP Exception: {exc.status_code} - {exc.detail} for {request.method} {request.url.path}") 
            if exc.status_code == 401:
                logger.error(f"Authentication error for request: {request.method} {request.url.path}")
            elif exc.status_code == 403:
                logger.error(f"Permission denied for request: {request.method} {request.url.path}")
        
        return JSONResponse(
            status_code=exc.status_code,
            content={"detail": exc.detail, "path": request.url.path},
        )
    
    logger.error(f"Unhandled exception in {request.method} {request.url.path}: {str(exc)}", exc_info=True)
    
    return JSONResponse(
        status_code=500,
        content={
            "detail": "An unexpected error occurred. Please try again later.",
            "path": request.url.path,
            "error_type": type(exc).__name__
        },
    )

# --- 라우트 정의 ---
@app.get("/")
async def root(request: Request):
    logger.info("Root endpoint '/' hit!")
    return templates.TemplateResponse("index.html", {"request": request})

@app.get("/api/health")
async def health_check():
    logger.info("Health check endpoint '/api/health' hit!")
    cpu_percent = psutil.cpu_percent()
    memory = psutil.virtual_memory()
    disk = psutil.disk_usage('/')
    
    return {
        "status": "ok",
        "system": {
            "cpu_percent": cpu_percent,
            "memory_percent": memory.percent,
            "disk_percent": disk.percent,
            "memory_available_mb": memory.available / (1024 * 1024),
            "rate_limit": MAX_REQUESTS_PER_MINUTE
        },
        "timestamp": time.time()
    }

@app.get("/api/metrics")
async def metrics():
    logger.info("Metrics endpoint '/api/metrics' hit!")
    cpu_percent = psutil.cpu_percent(interval=0.1, percpu=True)
    memory = psutil.virtual_memory()
    swap = psutil.swap_memory()
    disk = psutil.disk_usage('/')
    network = psutil.net_io_counters()
    
    return {
        "cpu": {
            "percent": cpu_percent,
            "cores": psutil.cpu_count(logical=True),
            "physical_cores": psutil.cpu_count(logical=False)
        },
        "memory": {
            "total_mb": memory.total / (1024 * 1024),
            "available_mb": memory.available / (1024 * 1024),
            "used_mb": memory.used / (1024 * 1024),
            "percent": memory.percent
        },
        "swap": {
            "total_mb": swap.total / (1024 * 1024),
            "used_mb": swap.used / (1024 * 1024),
            "percent": swap.percent
        },
        "disk": {
            "total_gb": disk.total / (1024 * 1024 * 1024),
            "used_gb": disk.used / (1024 * 1024 * 1024),
            "free_gb": disk.free / (1024 * 1024 * 1024),
            "percent": disk.percent
        },
        "network": {
            "bytes_sent_mb": network.bytes_sent / (1024 * 1024),
            "bytes_recv_mb": network.bytes_recv / (1024 * 1024)
        },
        "rate_limit": {
            "max_requests_per_minute": MAX_REQUESTS_PER_MINUTE
        },
        "timestamp": time.time()
    }

if __name__ == "__main__":
    import uvicorn
    
    uvicorn.run(
        "main:app",
        host="127.0.0.1",
        port=8000,
        reload=DEBUG_MODE,
        workers=1,
        timeout_keep_alive=65,
        access_log=DEBUG_MODE, # DEBUG_MODE가 True일 때 Uvicorn 액세스 로그 활성화
    )