import os
import logging
import tempfile
from pathlib import Path
from typing import List, Optional

from fastapi import UploadFile, HTTPException
from config.settings import MAX_FILE_SIZE, ALLOWED_EXTENSIONS

logger = logging.getLogger(__name__)

async def validate_file(file: UploadFile) -> None:
    """
    Validate the uploaded file:
    - Check if the file extension is allowed
    - Check if the file size is within limits
    """
    # Check file extension
    file_extension = Path(file.filename).suffix.lower()
    if file_extension not in ALLOWED_EXTENSIONS:
        allowed_ext_str = ", ".join(ALLOWED_EXTENSIONS)
        raise HTTPException(
            status_code=400, 
            detail=f"File type not allowed. Allowed types: {allowed_ext_str}"
        )
    
    # Check file size
    # First, get the file size
    file.file.seek(0, os.SEEK_END)
    file_size = file.file.tell()
    file.file.seek(0)  # Reset file position
    
    if file_size > MAX_FILE_SIZE:
        max_size_mb = MAX_FILE_SIZE / (1024 * 1024)
        raise HTTPException(
            status_code=400, 
            detail=f"File too large. Maximum size allowed: {max_size_mb}MB"
        )

async def save_upload_file_temp(upload_file: UploadFile) -> str:
    """
    Save an upload file temporarily and return the path.
    This is useful for processing files before uploading to blob storage.
    """
    try:
        # Create a temporary file
        suffix = Path(upload_file.filename).suffix
        with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as temp_file:
            # Read the uploaded file in chunks to avoid memory issues with large files
            chunk_size = 1024 * 1024  # 1MB chunks
            while chunk := await upload_file.read(chunk_size):
                temp_file.write(chunk)
            
            return temp_file.name
    except Exception as e:
        logger.error(f"Error saving temporary file: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error saving file: {str(e)}")

async def get_file_content_type(filename: str) -> str:
    """
    Determine the content type based on file extension
    """
    extension = Path(filename).suffix.lower()
    
    content_types = {
        ".txt": "text/plain",
        ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    }
    
    return content_types.get(extension, "application/octet-stream")

async def cleanup_temp_file(file_path: str) -> None:
    """
    Remove a temporary file
    """
    try:
        if os.path.exists(file_path):
            os.unlink(file_path)
    except Exception as e:
        logger.error(f"Error removing temporary file {file_path}: {str(e)}")
