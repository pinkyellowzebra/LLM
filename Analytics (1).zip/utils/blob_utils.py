import os
import logging
from datetime import datetime
from typing import Optional, List, Dict, Any

from azure.storage.blob.aio import BlobServiceClient
from azure.storage.blob import ContentSettings
from azure.core.exceptions import ResourceExistsError, ResourceNotFoundError

from config.settings import (
    AZURE_STORAGE_CONNECTION_STRING,
    AZURE_BLOB_CONTAINER_NAME,
    BLOB_FOLDER_FILES,
    BLOB_FOLDER_HISTORY,
    BLOB_FOLDER_USERS
)

logger = logging.getLogger(__name__)

class BlobStorageManager:
    """
    Manages interactions with Azure Blob Storage for storing, retrieving, and deleting files.
    It supports structured paths with optional user-specific subfolders.
    """
    def __init__(self):
        self.connection_string = AZURE_STORAGE_CONNECTION_STRING
        self.container_name = AZURE_BLOB_CONTAINER_NAME
        
        if not self.connection_string:
            logger.critical("Azure Storage Connection String is not set. Cannot initialize BlobStorageManager.")
            raise ValueError("Azure Storage Connection String (AZURE_STORAGE_CONNECTION_STRING) is not set.")
        
        logger.info(f"Initializing BlobStorageManager for container: '{self.container_name}'")
        # Log only a safe portion of the connection string to avoid exposing secrets
        logger.debug(f"Connection string prefix: {self.connection_string[:30]}...") 
        
        self._blob_service_client: Optional[BlobServiceClient] = None
    
    async def _get_blob_service_client(self) -> BlobServiceClient:
        """
        Ensures the BlobServiceClient is initialized (lazy initialization) and returns it.
        """
        if self._blob_service_client is None:
            try:
                self._blob_service_client = BlobServiceClient.from_connection_string(self.connection_string)
                logger.info("BlobServiceClient initialized asynchronously.")
            except Exception as e:
                logger.critical(f"Failed to initialize BlobServiceClient: {str(e)}", exc_info=True)
                raise ConnectionError("Could not connect to Azure Blob Storage. Check connection string.") from e
        return self._blob_service_client

    async def _ensure_container_exists(self):
        """
        Internal method to ensure that the required container exists in Azure Blob Storage.
        It attempts to create the container if it doesn't exist.
        """
        blob_service_client = await self._get_blob_service_client()
        try:
            container_client = blob_service_client.get_container_client(self.container_name)
            # Attempt to get properties to check existence
            await container_client.get_container_properties()
            logger.info(f"Container '{self.container_name}' already exists.")
        except ResourceNotFoundError:
            logger.info(f"Container '{self.container_name}' not found, attempting to create...")
            try:
                # Create the container with appropriate public access (consider 'none' or 'blob' for production)
                await blob_service_client.create_container(
                    name=self.container_name,
                    public_access='container' # Or 'blob' or 'none' based on requirements
                )
                logger.info(f"Container '{self.container_name}' created successfully.")
            except ResourceExistsError: 
                # This can happen if another process creates it concurrently
                logger.warning(f"Container '{self.container_name}' already exists, even though it was not found initially (race condition).")
            except Exception as e:
                logger.error(f"Error creating container '{self.container_name}': {str(e)}", exc_info=True)
                raise
        except Exception as e:
            logger.error(f"Error checking container '{self.container_name}': {str(e)}", exc_info=True)
            raise

    async def initialize_container(self):
        """
        Public method to initialize the container. Should be called once at application startup.
        """
        logger.info("Starting Blob Storage container initialization...")
        await self._ensure_container_exists()
        logger.info("Blob Storage container initialization complete.")
    
    # --- Internal Method for Path Construction ---
    def _get_full_blob_path(self, folder: str, blob_name: str, user_id: Optional[str] = None) -> str:
        """
        Constructs the full blob path within the container.
        Examples:
        - 'files/user-123/document.pdf'
        - 'history/uuid.json' (if user_id is None, though history usually has a user_id)

        Args:
            folder: The base folder name (e.g., BLOB_FOLDER_FILES).
            blob_name: The specific name of the blob (e.g., "my_document.xlsx").
            user_id: An optional user ID. If provided, creates a subfolder for the user.
        """
        if user_id:
            # Path: folder/user_id/blob_name
            full_path = f"{folder}/{user_id}/{blob_name}"
        else:
            # Path: folder/blob_name (for general folders or if user_id is not applicable)
            full_path = f"{folder}/{blob_name}"
        
        logger.debug(f"Constructed blob path: {full_path} for folder='{folder}', blob_name='{blob_name}', user_id='{user_id}'")
        return full_path

    async def upload_file(self, file_content: bytes, folder: str, blob_name: str, user_id: Optional[str] = None, content_type: Optional[str] = None, metadata: Optional[Dict[str, str]] = None) -> Dict[str, str]:
        """
        Uploads a file (bytes content) to Azure Blob Storage with optional metadata.
        Uses the structured folder/user_id/blob_name path.
        
        Args:
            file_content: The content of the file as bytes.
            folder: The base folder name (e.g., BLOB_FOLDER_FILES).
            blob_name: The specific name of the blob (e.g., "my_document.xlsx").
            user_id: The user ID to locate the specific subfolder (e.g., 'user-123').
            content_type: The MIME type of the file (e.g., "application/pdf").
            metadata: Optional dictionary of metadata to store with the blob.
            
        Returns:
            Dict[str, str]: A dictionary containing 'blob_name' (full path) and 'blob_url'.
        """
        blob_service_client = await self._get_blob_service_client()
        
        # Construct the full blob path using the internal helper
        full_blob_path = self._get_full_blob_path(folder, blob_name, user_id)

        try:
            logger.info(f"Attempting to upload blob to: {full_blob_path}", 
                        extra={"folder": folder, "blob_name": blob_name, "user_id": user_id, "content_type": content_type})
            
            container_client = blob_service_client.get_container_client(self.container_name)
            blob_client = container_client.get_blob_client(full_blob_path)
            
            content_settings = ContentSettings(content_type=content_type) if content_type else None
            
            await blob_client.upload_blob(
                file_content, 
                content_settings=content_settings, 
                metadata=metadata, 
                overwrite=True # Always overwrite if exists (e.g., updating a user profile image)
            )
            logger.info(f"Blob upload completed successfully for {full_blob_path}",
                        extra={"full_blob_path": full_blob_path, "size_bytes": len(file_content)})
            
            return {
                "blob_name": full_blob_path, # Return the full path
                "blob_url": blob_client.url
            }
        except Exception as e:
            logger.error(f"Error uploading file to blob storage at path '{full_blob_path}': {str(e)}", 
                         exc_info=True, 
                         extra={"full_blob_path": full_blob_path, "folder": folder, "blob_name": blob_name, "user_id": user_id})
            raise

    async def get_blob_properties(self, blob_path: str) -> Optional[Dict[str, Any]]:
        """
        Retrieves properties and metadata for a specific blob using its full path.
        This method expects the complete blob_path (e.g., 'history/user-id/uuid.json').
        
        Args:
            blob_path: The full path of the blob within the container.
            
        Returns:
            Optional[Dict[str, Any]]: A dictionary of blob properties and metadata, or None if not found.
        """
        blob_service_client = await self._get_blob_service_client()
        try:
            blob_client = blob_service_client.get_blob_client(
                container=self.container_name, 
                blob=blob_path # Expects the full blob path
            )
            properties = await blob_client.get_blob_properties()
            logger.info(f"Successfully retrieved properties for blob: {blob_path}",
                        extra={"blob_path": blob_path, "size": properties.size, "last_modified": properties.last_modified})
            
            return {
                "name": properties.name,
                "size": properties.size,
                "creation_time": properties.creation_time,
                "last_modified": properties.last_modified,
                "etag": properties.etag,
                "content_settings": {
                    "content_type": properties.content_settings.content_type,
                    "content_md5": properties.content_settings.content_md5,
                },
                "metadata": properties.metadata if properties.metadata else {} # Ensure metadata is a dict
            }
        except ResourceNotFoundError:
            logger.warning(f"Blob '{blob_path}' not found when trying to get properties.",
                           extra={"blob_path": blob_path})
            return None
        except Exception as e:
            logger.error(f"Error getting properties for blob '{blob_path}': {str(e)}", 
                         exc_info=True, 
                         extra={"blob_path": blob_path})
            raise

    async def delete_file(self, folder: str, blob_name: str, user_id: Optional[str] = None) -> bool:
        """
        Deletes a file from Azure Blob Storage using the structured folder/user_id/blob_name path.
        
        Args:
            folder: The base folder name (e.g., BLOB_FOLDER_HISTORY).
            blob_name: The specific name of the blob within the user's folder (e.g., "uuid.json").
            user_id: The user ID to locate the specific subfolder (e.g., 'user-123').
            
        Returns:
            bool: True if the deletion was successful, False if the blob was not found.
        """
        blob_service_client = await self._get_blob_service_client()
        
        # Construct the full blob path using the internal helper
        full_blob_path = self._get_full_blob_path(folder, blob_name, user_id)

        try:
            blob_client = blob_service_client.get_blob_client(
                container=self.container_name, 
                blob=full_blob_path
            )
            
            await blob_client.delete_blob()
            logger.info(f"Successfully deleted blob: {full_blob_path}",
                        extra={"full_blob_path": full_blob_path, "user_id": user_id})
            return True
        except ResourceNotFoundError:
            logger.warning(f"Blob '{full_blob_path}' not found for deletion. No action taken.",
                           extra={"full_blob_path": full_blob_path, "user_id": user_id})
            return False
        except Exception as e:
            logger.error(f"Error deleting blob '{full_blob_path}': {str(e)}", 
                         exc_info=True, 
                         extra={"full_blob_path": full_blob_path, "user_id": user_id})
            raise
    
    async def save_data(self, folder: str, blob_name: str, data: bytes, content_type: Optional[str] = None, user_id: Optional[str] = None, metadata: Optional[Dict[str, str]] = None) -> Dict[str, str]:
        """
        Saves generic data (bytes) to a specific folder in the main container with optional user-specific path and metadata.
        This method is a generalized version of `upload_file` for arbitrary data.
        
        Args:
            folder: The base folder name.
            blob_name: The specific name of the blob.
            data: The content to save as bytes.
            content_type: The MIME type of the data.
            user_id: Optional user ID for subfolder organization.
            metadata: Optional dictionary of metadata.
            
        Returns:
            Dict[str, str]: A dictionary containing 'blob_name' (full path) and 'blob_url'.
        """
        blob_service_client = await self._get_blob_service_client()
        
        full_blob_path = self._get_full_blob_path(folder, blob_name, user_id)
        
        try:
            blob_client = blob_service_client.get_blob_client(
                container=self.container_name, 
                blob=full_blob_path
            )
            
            content_settings = ContentSettings(content_type=content_type) if content_type else None
            
            await blob_client.upload_blob(data, content_settings=content_settings, metadata=metadata, overwrite=True)
            logger.info(f"Successfully saved data to blob: {full_blob_path}",
                        extra={"full_blob_path": full_blob_path, "folder": folder, "user_id": user_id, "size_bytes": len(data)})
            
            return {
                "blob_name": full_blob_path,
                "blob_url": blob_client.url
            }
        except Exception as e:
            logger.error(f"Error saving data to blob '{full_blob_path}': {str(e)}", 
                         exc_info=True, 
                         extra={"full_blob_path": full_blob_path, "folder": folder, "user_id": user_id})
            raise
    
    async def get_data_by_full_path(self, blob_path: str) -> Optional[bytes]:
        """
        Retrieves data directly from Azure Blob Storage using a full blob path.
        This method is suitable when the complete blob path is already known
        (e.g., from a database record or a service response).
        
        Args:
            blob_path: The full path of the blob within the container.
            
        Returns:
            Optional[bytes]: The content of the blob as bytes, or None if not found.
        """
        blob_service_client = await self._get_blob_service_client()
        try:
            blob_client = blob_service_client.get_blob_client(
                container=self.container_name, 
                blob=blob_path # Expects the full blob path
            )
            
            download_stream = await blob_client.download_blob()
            data = await download_stream.readall()
            logger.info(f"Successfully retrieved data from blob: {blob_path}",
                        extra={"blob_path": blob_path, "size_bytes": len(data)})
            
            return data
        except ResourceNotFoundError:
            logger.warning(f"Blob '{blob_path}' not found when trying to retrieve data.",
                           extra={"blob_path": blob_path})
            return None
        except Exception as e:
            logger.error(f"Error retrieving data from blob '{blob_path}': {str(e)}", 
                         exc_info=True, 
                         extra={"blob_path": blob_path})
            raise

    async def get_data(self, folder: str, blob_name: str, user_id: Optional[str] = None) -> Optional[bytes]:
        """
        Retrieves data from a specific folder with optional user-specific path.
        This method uses the _get_full_blob_path helper internally.
        
        Args:
            folder: The base folder name.
            blob_name: The specific name of the blob.
            user_id: Optional user ID for subfolder organization.
            
        Returns:
            Optional[bytes]: The content of the blob as bytes, or None if not found.
        """
        blob_service_client = await self._get_blob_service_client()
        
        full_blob_path = self._get_full_blob_path(folder, blob_name, user_id)
        
        try:
            blob_client = blob_service_client.get_blob_client(
                container=self.container_name, 
                blob=full_blob_path
            )
            
            download_stream = await blob_client.download_blob()
            data = await download_stream.readall()
            logger.info(f"Successfully retrieved data from blob: {full_blob_path}",
                        extra={"full_blob_path": full_blob_path, "folder": folder, "user_id": user_id})
            
            return data
        except ResourceNotFoundError:
            logger.warning(f"Blob '{full_blob_path}' not found when trying to retrieve data.",
                           extra={"full_blob_path": full_blob_path, "folder": folder, "user_id": user_id})
            return None
        except Exception as e:
            logger.error(f"Error retrieving data from blob '{full_blob_path}': {str(e)}", 
                         exc_info=True, 
                         extra={"full_blob_path": full_blob_path, "folder": folder, "user_id": user_id})
            raise
    
    async def list_blobs_in_container(self, container_name: str = AZURE_BLOB_CONTAINER_NAME, prefix: Optional[str] = None, max_results: int = 100) -> List[Dict[str, Any]]:
        """
        Lists all blobs in a specific container (defaults to the configured one), optionally filtered by a prefix.
        This method is for general container listing, not necessarily tied to folder/user_id structure.
        """
        blob_service_client = await self._get_blob_service_client()
        try:
            container_client = blob_service_client.get_container_client(container_name)
            
            listed_blobs = []
            # list_blobs returns an AsyncItemPaged iterator
            async for blob in container_client.list_blobs(name_starts_with=prefix, results_per_page=max_results):
                listed_blobs.append({
                    "name": blob.name, # Use 'name' for the full blob path
                    "created_on": blob.creation_time,
                    "size": blob.size,
                    "etag": blob.etag,
                    "last_modified": blob.last_modified,
                    "metadata": blob.metadata if blob.metadata else {}
                })
            logger.info(f"Listed {len(listed_blobs)} blobs in container '{container_name}' with prefix '{prefix}'.",
                        extra={"container_name": container_name, "prefix": prefix, "blob_count": len(listed_blobs)})
            return listed_blobs
        except Exception as e:
            logger.error(f"Error listing blobs in container '{container_name}' with prefix '{prefix}': {str(e)}", 
                         exc_info=True, 
                         extra={"container_name": container_name, "prefix": prefix})
            raise
    
    async def list_blobs_in_folder(self, folder: str, user_id: Optional[str] = None, max_results: int = 100) -> List[Dict[str, Any]]:
        """
        Lists all blobs within a specific folder (and optional user-specific subfolder) in the main container.
        This method constructs the prefix based on folder and user_id to simulate folder listing.
        
        Args:
            folder: The base folder name (e.g., BLOB_FOLDER_HISTORY).
            user_id: Optional user ID to list blobs only within that user's subfolder.
            max_results: Maximum number of results to fetch per page.
            
        Returns:
            List[Dict[str, Any]]: A list of dictionaries, each representing a blob with its properties.
        """
        blob_service_client = await self._get_blob_service_client()
        try:
            container_client = blob_service_client.get_container_client(self.container_name)
            
            # Construct the prefix based on folder and optional user_id
            prefix = f"{folder}/"
            if user_id:
                prefix += f"{user_id}/"
            
            listed_blobs = []
            # list_blobs returns an AsyncItemPaged iterator
            async for blob in container_client.list_blobs(name_starts_with=prefix, results_per_page=max_results):
                listed_blobs.append({
                    "name": blob.name, # This will be the full path like 'history/user-id/uuid.json'
                    "created_on": blob.creation_time,
                    "size": blob.size,
                    "etag": blob.etag,
                    "last_modified": blob.last_modified,
                    "metadata": blob.metadata if blob.metadata else {} # Include metadata for HistoryItem construction
                })
            logger.info(f"Listed {len(listed_blobs)} blobs in folder '{prefix}'.",
                        extra={"folder": folder, "user_id": user_id, "prefix": prefix, "blob_count": len(listed_blobs)})
            return listed_blobs
        except Exception as e:
            logger.error(f"Error listing blobs in folder '{prefix}': {str(e)}", 
                         exc_info=True, 
                         extra={"folder": folder, "user_id": user_id, "prefix": prefix})
            raise

# Create a singleton instance for global access
blob_storage_manager = BlobStorageManager()