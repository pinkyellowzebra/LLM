from datetime import datetime, timezone, timedelta # timedelta 임포트 추가
import time
from typing import Tuple

def get_utc_now() -> datetime:
    """
    현재 UTC 시각을 datetime 객체로 반환합니다.
    이 함수는 내부 로직 (Pydantic 모델, 데이터베이스 저장 등)에서 사용됩니다.
    """
    return datetime.now(timezone.utc)

def format_datetime_korean(dt: datetime) -> str:
    """
    datetime 객체를 'yyyy년 mm월 dd일 오전/오후 h시 m분 s초' 형식의 문자열로 포맷합니다.
    이 함수는 주로 사용자 인터페이스 (UI)에 시간을 표시할 때 사용합니다.
    입력된 datetime 객체가 UTC라면 한국 시간 (KST, UTC+9)으로 변환하여 표시합니다.
    """
    if dt.tzinfo is not None and dt.tzinfo.utcoffset(dt) == timedelta(0):
        # 입력된 dt가 UTC인 경우 (tzinfo가 있고 오프셋이 0) 한국 시간으로 변환
        dt_kst = dt.astimezone(timezone(timedelta(hours=9)))
    else:
        # 그 외의 경우 (예: naive datetime 또는 다른 시간대 datetime), 시스템 기본 시간대로 변환 시도
        # 이 경우 정확한 변환을 위해서는 입력 dt의 시간대 정보가 명확해야 합니다.
        dt_kst = dt.astimezone() 
    
    am_pm = "오전" if dt_kst.hour < 12 else "오후"
    hour = dt_kst.hour % 12
    if hour == 0:
        hour = 12
    
    return f"{dt_kst.year}년 {dt_kst.month:02d}월 {dt_kst.day:02d}일 {am_pm} {hour}시 {dt_kst.minute:02d}분 {dt_kst.second:02d}초"

def get_execution_time(start_time: float) -> Tuple[str, float]:
    """
    시작 시간으로부터의 실행 시간을 계산하고 포맷된 문자열과 초 단위로 반환합니다.
    """
    end_time = time.time()
    execution_time_seconds = end_time - start_time
    
    if execution_time_seconds < 60:
        formatted_time = f"{execution_time_seconds:.1f}s"
    elif execution_time_seconds < 3600:
        minutes = int(execution_time_seconds // 60)
        seconds = execution_time_seconds % 60
        formatted_time = f"{minutes}m {seconds:.1f}s"
    else:
        hours = int(execution_time_seconds // 3600)
        minutes = int((execution_time_seconds % 3600) // 60)
        seconds = execution_time_seconds % 60
        formatted_time = f"{hours}h {minutes}m {seconds:.1f}s"
    
    return formatted_time, execution_time_seconds

def parse_timestamp_from_blob_name(blob_name: str) -> datetime:
    """
    'history_YYYYMMDDHHMMSS.json' 형식의 Blob 이름에서 타임스탬프를 파싱합니다.
    파싱된 시간은 UTCaware datetime 객체로 반환됩니다.
    Blob 이름의 타임스탬프가 UTC를 기준으로 생성되었다고 가정합니다.
    """
    try:
        timestamp_str = blob_name.replace("history_", "").replace(".json", "")
        # 파싱 후 UTC 시간대 정보 추가
        return datetime.strptime(timestamp_str, "%Y%m%d%H%M%S").replace(tzinfo=timezone.utc)
    except Exception:
        # 파싱 실패 시, 현재 UTC 시간을 반환하여 일관성 유지
        return datetime.now(timezone.utc)