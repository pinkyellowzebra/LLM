# C:\Users\eunhee.hong\Desktop\Analytics\service\file_service.py

import logging
import mimetypes
import os
from typing import Optional, Dict, Any, List
from datetime import datetime, timezone

from fastapi import UploadFile, HTTPException, status

from models.schemas import FileUploadResponse, FileDeleteResponse
from utils.blob_utils import blob_storage_manager
from config.settings import BLOB_FOLDER_FILES

logger = logging.getLogger(__name__)

class FileService:
    """
    파일 업로드, 목록 조회, 삭제와 관련된 비즈니스 로직을 처리하는 서비스입니다.
    """

    @staticmethod
    async def upload_file(file: UploadFile, user_id: Optional[str] = None) -> FileUploadResponse:
        """
        주어진 파일을 Azure Blob Storage에 업로드하고 관련 정보를 반환합니다.

        Args:
            file: 업로드할 파일 (FastAPI UploadFile 객체).
            user_id: 파일을 업로드하는 사용자의 ID (선택 사항). 블롭 메타데이터에 저장됩니다.

        Returns:
            FileUploadResponse: 업로드된 파일의 정보.

        Raises:
            HTTPException: 파일 형식, 크기 제한 위반 또는 업로드 실패 시 발생.
        """
        allowed_extensions = [".txt", ".xlsx"]
        max_file_size_mb = 50
        max_file_size_bytes = max_file_size_mb * 1024 * 1024

        file_extension = os.path.splitext(file.filename)[1].lower()
        if file_extension not in allowed_extensions:
            logger.warning(f"지원되지 않는 파일 형식: {file.filename} ({file.content_type})",
                           extra={"user_id": user_id, "file_name": file.filename})
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"지원되는 파일 형식은 {', '.join(allowed_extensions)}입니다."
            )

        file_content = await file.read()
        if len(file_content) > max_file_size_bytes:
            logger.warning(f"파일 크기 초과: {file.filename} ({len(file_content)} bytes)",
                           extra={"user_id": user_id, "file_name": file.filename})
            raise HTTPException(
                status_code=status.HTTP_413_PAYLOAD_TOO_LARGE,
                detail=f"파일 크기는 {max_file_size_mb}MB를 초과할 수 없습니다."
            )

        timestamp = datetime.now(timezone.utc)
        base_filename = os.path.splitext(file.filename)[0]
        final_blob_filename = f"{base_filename}_{timestamp.strftime('%Y%m%d%H%M%S')}{file_extension}"
        
        user_folder_name = f"user-{user_id}" if user_id else None

        content_type = file.content_type
        if not content_type or content_type == "application/octet-stream":
            guessed_type = mimetypes.guess_type(file.filename)[0]
            if guessed_type:
                content_type = guessed_type
            else:
                content_type = "application/octet-stream"

        metadata = {"user_id": user_id} if user_id else {}

        try:
            result = await blob_storage_manager.upload_file(
                file_content,
                folder=BLOB_FOLDER_FILES,
                blob_name=final_blob_filename,
                user_id=user_folder_name, # 'user-{id}' 또는 None
                content_type=content_type,
                metadata=metadata
            )
            
            if result:
                logger.info(f"파일 {file.filename}을(를) 블롭 {result['blob_name']}으로 성공적으로 업로드했습니다.",
                            extra={"user_id": user_id, "blob_name": result['blob_name']})
                return FileUploadResponse(
                    blob_name=result["blob_name"], # _get_full_blob_path로 생성된 전체 경로
                    blob_url=result.get("blob_url", f"https://yourstorageaccount.blob.core.windows.net/yourcontainer/{result['blob_name']}"),
                    filename=file.filename,
                    content_type=content_type,
                    size=len(file_content),
                    upload_time=datetime.now(timezone.utc)
                )
            else:
                logger.error(f"Blob Storage에 파일 업로드 실패: {file.filename}",
                             extra={"user_id": user_id, "file_name": file.filename})
                raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="파일 업로드에 실패했습니다.")
        except HTTPException:
            raise # 이미 HTTPException이 발생한 경우 그대로 전파
        except Exception as e:
            logger.error(f"Azure Blob Storage 업로드 중 오류 발생: {str(e)}", exc_info=True,
                         extra={"user_id": user_id, "file_name": file.filename})
            raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"파일 업로드 중 서버 오류가 발생했습니다: {str(e)}")


    
    @staticmethod
    async def list_files(user_id: str) -> List[Dict[str, Any]]:
        """
        지정된 사용자가 업로드한 파일 목록을 Blob Storage에서 조회합니다.
        파일 목록을 file_routes.py에서 필요한 스키마에 맞게 포맷하여 반환합니다.

        Args:
            user_id: 파일 목록을 조회할 사용자의 ID.

        Returns:
            List[Dict[str, Any]]: 포맷된 파일 정보 딕셔너리 리스트.

        Raises:
            HTTPException: 파일 목록 조회 중 오류 발생 시.
        """
        logger.info(f"사용자 {user_id}의 파일 목록 조회 시도", extra={"user_id": user_id})
        try:
            # blob_storage_manager를 호출하여 해당 사용자의 파일을 가져옵니다.
            # blob_utils.py의 list_blobs_in_folder는 user_id에 따라 'user-{id}' 폴더를 자동으로 고려합니다.
            files_data = await blob_storage_manager.list_blobs_in_folder(
                folder=BLOB_FOLDER_FILES, # 예: 'files'
                user_id=user_id           # 예: '123' (list_blobs_in_folder 내부에서 'user-123'으로 변환)
            )
            
            formatted_files = []
            for file_info in files_data:
                # blob_name은 'files/user-123/my_document.xlsx'와 같은 전체 경로입니다.
                formatted_files.append({
                    "file_id": file_info["blob_name"], # routes에서 이 값을 사용하여 개별 파일에 접근할 수 있도록 전체 경로를 ID로 사용
                    "file_name": os.path.basename(file_info["blob_name"]), # 원본 파일명
                    "file_size": file_info["size"],
                    "upload_time": file_info["created_on"].isoformat() if file_info.get("created_on") else None, # created_on이 없을 수도 있으므로 get 사용
                    "metadata": file_info.get("metadata", {}) # metadata가 없을 수도 있으므로 get 사용
                })
            logger.info(f"사용자 {user_id}에 대해 {len(formatted_files)}개의 파일 항목 조회 성공",
                        extra={"user_id": user_id, "file_count": len(formatted_files)})
            return formatted_files
        except Exception as e:
            logger.error(f"파일 목록 조회 중 서비스 오류 발생: {e}", exc_info=True, extra={"user_id": user_id})
            raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"파일 목록 조회 중 오류 발생: {str(e)}")



    @staticmethod
    async def delete_file(blob_full_path: str, user_id: Optional[str] = None) -> FileDeleteResponse:
        """
        Azure Blob Storage에서 지정된 블롭을 삭제합니다.
        사용자 ID가 제공된 경우 파일 소유권을 확인합니다.

        Args:
            blob_full_path: 삭제할 블롭의 전체 이름 (예: 'files/user-abc/my_file_20250619.xlsx').
            user_id: 파일을 삭제하려는 사용자의 ID (선택 사항).

        Returns:
            FileDeleteResponse: 삭제 성공 여부와 메시지.

        Raises:
            HTTPException: 파일이 없거나, 권한이 없거나, 삭제 실패 시 발생.
        """
        logger.info(f"사용자 {user_id}가 파일 '{blob_full_path}' 삭제 시도",
                    extra={"user_id": user_id, "blob_full_path": blob_full_path})
        
        try:
            # 1. 블롭 존재 여부 및 메타데이터 확인 (소유권 확인을 위해)
            # blob_storage_manager.get_blob_properties 메서드가 해당 블롭의 전체 경로를 인자로 받도록 가정
            blob_properties = await blob_storage_manager.get_blob_properties(blob_full_path)
            
            if not blob_properties:
                logger.warning(f"삭제하려는 블롭 {blob_full_path}를 찾을 수 없습니다.",
                               extra={"user_id": user_id, "blob_full_path": blob_full_path})
                raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"파일을 찾을 수 없습니다: {blob_full_path}")

            # 2. 파일 소유권 확인 로직
            # 블롭 메타데이터에 저장된 user_id와 현재 요청 user_id를 비교
            owner_user_id = blob_properties.get("metadata", {}).get("user_id")
            
            if user_id and owner_user_id and owner_user_id != user_id:
                logger.warning(f"사용자 {user_id}가 사용자 {owner_user_id} 소유의 블롭 {blob_full_path}을(를) 삭제하려 시도했습니다. 권한 거부됨.",
                               extra={"user_id": user_id, "owner_user_id": owner_user_id, "blob_full_path": blob_full_path})
                raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="이 파일을 삭제할 권한이 없습니다.")
            
            # (선택 사항) 'general' 폴더 파일 처리: user_id가 없는 경우에만 삭제 허용
            # blob_full_path 예: 'files/general/some_file.txt'
            is_general_file = blob_full_path.startswith(f"{BLOB_FOLDER_FILES}/general/")
            if is_general_file and user_id is not None:
                # 일반 파일은 특정 사용자에게 귀속되지 않으므로, 인증된 사용자는 삭제할 수 없도록 제한 (혹은 관리자만)
                # 이 로직은 앱의 비즈니스 규칙에 따라 달라질 수 있습니다.
                logger.warning(f"인증된 사용자({user_id})가 'general' 폴더의 파일({blob_full_path})을 삭제하려 시도했습니다. 권한 거부됨.",
                               extra={"user_id": user_id, "blob_full_path": blob_full_path})
                raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="이 파일은 공용 파일이거나 관리자 전용이므로 삭제할 수 없습니다.")
            
            # 3. Blob Storage에서 파일 삭제
            # blob_storage_manager.delete_blob이 blob_full_path를 직접 인자로 받도록 가정
            delete_success = await blob_storage_manager.delete_blob(blob_full_path)

            if delete_success:
                logger.info(f"블롭 {blob_full_path}가 성공적으로 삭제되었습니다.",
                            extra={"user_id": user_id, "blob_full_path": blob_full_path})
                return FileDeleteResponse(success=True, message=f"파일 {blob_full_path}이(가) 성공적으로 삭제되었습니다.")
            else:
                logger.error(f"Blob Storage에서 블롭 {blob_full_path} 삭제 실패 (Blob Storage 반환: False).",
                             extra={"user_id": user_id, "blob_full_path": blob_full_path})
                raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"파일 {blob_full_path} 삭제에 실패했습니다.")

        except HTTPException:
            raise # 이미 발생한 HTTPException은 그대로 다시 발생
        except Exception as e:
            logger.error(f"파일 {blob_full_path} 삭제 중 오류 발생: {str(e)}", exc_info=True,
                         extra={"user_id": user_id, "blob_full_path": blob_full_path})
            raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"파일 삭제 중 서버 오류가 발생했습니다: {str(e)}")