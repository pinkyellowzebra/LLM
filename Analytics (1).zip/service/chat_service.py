import os
import json
import time
import logging
import tempfile
from typing import List, Dict, Any, Optional, Tuple
import base64
from io import BytesIO

import openai
from openai import AzureOpenAI
from fastapi import HTTPException, status
# Specific OpenAI types for better type hinting
from openai.types.beta.thread import Thread
from openai.types.beta.threads.message import Message
from openai.types.beta.threads.run import Run
# CHANGED IMPORT HERE: Corrected import path for content block types
from openai.types.beta.threads.message_content import TextContentBlock, ImageFileContentBlock

from config.settings import (
    AZURE_OPENAI_API_KEY,
    AZURE_OPENAI_ENDPOINT,
    AZURE_OPENAI_API_VERSION,
    AZURE_OPENAI_DEPLOYMENT_NAME,
    BLOB_FOLDER_FILES
)
from models.schemas import ChatMessage, ChatResponse
from utils.time_utils import get_utc_now, get_execution_time
from utils.blob_utils import blob_storage_manager
# from service.history_service import HistoryService # This import is intentionally commented out for circular dependency resolution
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class ChatService:
    """
    Service for handling chat operations with Azure OpenAI Assistants API.
    Manages threads, messages, file attachments, and integrates with history service.
    """

    def __init__(self, assistant_id: str):
        self.client = AzureOpenAI(
            api_key=AZURE_OPENAI_API_KEY,
            api_version=AZURE_OPENAI_API_VERSION,
            azure_endpoint=AZURE_OPENAI_ENDPOINT
        )
        self.assistant_id = assistant_id
        logger.info(f"ChatService initialized with assistant ID: {self.assistant_id}")

    async def delete_thread(self, thread_id: str) -> bool:
        """
        Deletes an Azure OpenAI Assistant Thread.
        Returns True if successful or if the thread was not found (already deleted).
        Returns False if another error occurs during deletion.
        """
        try:
            logger.info(f"Attempting to delete Azure OpenAI thread: {thread_id}", extra={"thread_id": thread_id})
            response = self.client.beta.threads.delete(thread_id)
            if response.deleted:
                logger.info(f"Successfully deleted Azure OpenAI thread: {thread_id}", extra={"thread_id": thread_id})
                return True
            else:
                logger.warning(f"Azure OpenAI thread {thread_id} not reported as deleted by API. Response: {response}", extra={"thread_id": thread_id, "api_response": response.model_dump_json()})
                return False
        except openai.NotFoundError:
            logger.info(f"Attempted to delete thread {thread_id} but it was not found in OpenAI (likely already deleted). Considering it a success.", extra={"thread_id": thread_id})
            return True # Consider it a success if it's already gone
        except Exception as e:
            logger.error(f"Error deleting Azure OpenAI thread {thread_id}: {e}", exc_info=True, extra={"thread_id": thread_id})
            return False

    async def delete_file(self, file_id: str) -> bool:
        """
        Deletes a file uploaded to Azure OpenAI.
        Returns True if successful or if the file was not found (already deleted).
        Returns False if another error occurs during deletion.
        """
        try:
            logger.info(f"Attempting to delete Azure OpenAI file: {file_id}", extra={"openai_file_id": file_id})
            response = self.client.files.delete(file_id)
            if response.deleted:
                logger.info(f"Successfully deleted Azure OpenAI file: {file_id}", extra={"openai_file_id": file_id})
                return True
            else:
                logger.warning(f"Azure OpenAI file {file_id} not reported as deleted by API. Response: {response}", extra={"openai_file_id": file_id, "api_response": response.model_dump_json()})
                return False
        except openai.NotFoundError:
            logger.info(f"Attempted to delete file {file_id} but it was not found in OpenAI (likely already deleted). Considering it a success.", extra={"openai_file_id": file_id})
            return True # Consider it a success if it's already gone
        except Exception as e:
            logger.error(f"Error deleting Azure OpenAI file {file_id}: {e}", exc_info=True, extra={"openai_file_id": file_id})
            return False

    async def process_chat(
        self,
        message: str,
        file_blob_name: Optional[str] = None,
        history_id: Optional[str] = None,
        user_id: Optional[str] = None,
        # history_service: 'HistoryService' is added here for dependency injection
        history_service: Any = None # Changed type hint for circular dependency
    ) -> ChatResponse:
        start_time = time.time()

        # Ensure history_service is provided
        if history_service is None:
            logger.critical("HistoryService dependency not provided to ChatService.process_chat.")
            raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Server configuration error: History service not available.")

        try:
            previous_messages: List[ChatMessage] = []
            thread_id: Optional[str] = None # OpenAI Thread ID

            # These variables will store the *actual* file info used for the current chat turn
            current_chat_blob_path: Optional[str] = None # Full blob path (e.g., 'files/user-abc/data.xlsx')
            current_openai_file_id: Optional[str] = None # OpenAI File ID

            # 1. Load previous conversation history and extract thread_id, openai_file_id, file_used
            if history_id:
                history_item = await history_service.get_history(history_id, user_id)
                if history_item:
                    # If history exists, populate initial values from it
                    previous_messages = history_item.messages
                    thread_id = history_item.thread_id
                    current_chat_blob_path = history_item.file_used # Start by assuming historical file is used
                    current_openai_file_id = history_item.openai_file_id # Start by assuming historical OpenAI file ID is used

                    logger.info(f"Loaded history {history_id}. Thread ID: {thread_id}, OpenAI File ID (history): {current_openai_file_id}, Blob File Used (history): {history_item.file_used}",
                                 extra={"history_id": history_id, "thread_id": thread_id, "openai_file_id_history": current_openai_file_id, "blob_file_used_history": history_item.file_used})
                else:
                    logger.warning(f"History ID {history_id} not found. Starting new conversation.", extra={"history_id": history_id})
                    history_id = None # Invalidate history_id to ensure a new one is created

            # 2. Manage OpenAI Thread: Reuse existing thread or create a new one
            if not thread_id:
                thread = await self._create_thread()
                thread_id = thread.id
                logger.info(f"Created new OpenAI thread: {thread_id}", extra={"thread_id": thread_id})
            else:
                try:
                    thread = self.client.beta.threads.retrieve(thread_id)
                    logger.info(f"Reusing existing OpenAI thread: {thread_id}", extra={"thread_id": thread_id})
                except openai.NotFoundError:
                    logger.warning(f"Thread {thread_id} not found in OpenAI, creating new one.", extra={"thread_id": thread_id})
                    thread = await self._create_thread()
                    thread_id = thread.id # Update with the newly created thread ID
                except Exception as e:
                    logger.error(f"Error retrieving thread {thread_id}: {e}, creating new one.", exc_info=True, extra={"thread_id": thread_id})
                    thread = await self._create_thread()
                    thread_id = thread.id

            # --- 3. File Processing: Determine which file to attach to the Assistant for this conversation turn ---
            # If a new file_blob_name is provided in the current request, it overrides any historical file.
            if file_blob_name:
                logger.info(f"New file '{file_blob_name}' provided in request. Overriding historical file if any.", extra={"new_file_blob_name": file_blob_name, "old_openai_file_id": current_openai_file_id})
                # If there was an old OpenAI file from history AND a new file is provided, delete the old OpenAI file.
                if current_openai_file_id:
                    logger.info(f"New file provided. Deleting old OpenAI file: {current_openai_file_id} from previous turn.", extra={"old_openai_file_id_to_delete": current_openai_file_id})
                    await self.delete_file(current_openai_file_id) # Await but don't re-raise on failure

                # Upload the new file to OpenAI
                uploaded_openai_file_id = await self._add_file_to_thread(file_blob_name)
                if not uploaded_openai_file_id:
                    logger.error(f"Failed to upload file {file_blob_name} to OpenAI. Aborting chat process.", extra={"blob_file_name_failed": file_blob_name})
                    raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Failed to upload data file for analysis.")

                current_chat_blob_path = file_blob_name # The new file's blob path
                current_openai_file_id = uploaded_openai_file_id # The new OpenAI file ID
                logger.info(f"New file '{current_chat_blob_path}' successfully uploaded to OpenAI with ID: {current_openai_file_id}",
                                 extra={"current_chat_blob_path": current_chat_blob_path, "current_openai_file_id": current_openai_file_id})
            elif current_chat_blob_path and current_openai_file_id:
                # No new file provided, but a historical file was present. Reuse it.
                logger.info(f"No new file provided in request. Reusing historical blob file: {current_chat_blob_path} and OpenAI file ID: {current_openai_file_id}",
                                 extra={"current_chat_blob_path": current_chat_blob_path, "current_openai_file_id": current_openai_file_id})
            else:
                # No file in current request, and no historical file. Proceed without a file.
                logger.info("No file provided for this chat turn (new or historical). Proceeding without file attachment.")
                current_chat_blob_path = None
                current_openai_file_id = None


            # 4. Add user message to the thread
            user_chat_message = ChatMessage(
                role="user",
                content=message,
                timestamp=get_utc_now()
            )

            await self._add_message_to_thread(
                thread_id,
                "user",
                message,
                file_ids=[current_openai_file_id] if current_openai_file_id else None
            )
            logger.info(f"User message added to thread {thread_id} with file ID: {current_openai_file_id}",
                             extra={"thread_id": thread_id, "user_message_len": len(message), "attached_file_id": current_openai_file_id})

            # 5. Run Assistant and wait for response
            logger.info(f"Running assistant {self.assistant_id} on thread {thread_id}...", extra={"assistant_id": self.assistant_id, "thread_id": thread_id})
            run = await self._run_assistant(thread_id, self.assistant_id)
            run = await self._wait_for_run(thread_id, run.id)
            logger.info(f"Assistant run {run.id} completed with status: {run.status}", extra={"thread_id": thread_id, "run_id": run.id, "run_status": run.status})

            # 6. Retrieve Assistant's response
            messages_page = await self._get_thread_messages(thread_id)
            assistant_message_content = ""
            charts = []

            # OpenAI's list messages returns newest first, so the first assistant message is the relevant one
            # Iterate through messages and their content, expecting the latest assistant message
            for msg in messages_page.data:
                if msg.role == "assistant":
                    logger.info(f"Processing assistant message {msg.id} from thread {thread_id}", extra={"message_id": msg.id, "thread_id": thread_id})
                    for content_item in msg.content:
                        # CHANGED HERE: Use TextContentBlock and ImageFileContentBlock
                        if isinstance(content_item, ImageFileContentBlock):
                            image_file_id = content_item.image_file.file_id
                            logger.info(f"Found image file with ID: {image_file_id}", extra={"image_file_id": image_file_id})
                            image_data_base64 = await self._get_image_file_content_base64(image_file_id)
                            if image_data_base64:
                                charts.append({
                                    "type": "image",
                                    "data": f"data:image/png;base64,{image_data_base64}"
                                })
                        elif isinstance(content_item, TextContentBlock):
                            assistant_message_content = content_item.text.value
                            logger.debug(f"Found text content from assistant: {assistant_message_content[:100]}...", extra={"thread_id": thread_id, "message_id": msg.id, "content_preview": assistant_message_content[:100]})
                    break # Process only the first (most recent) assistant message, which should contain all its parts

            if not assistant_message_content and not charts:
                if not messages_page.data or not any(msg.role == "assistant" for msg in messages_page.data):
                    logger.error(f"No assistant response received or assistant message is empty for thread {thread_id}.", extra={"thread_id": thread_id})
                    raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="No assistant response received or assistant message is empty.")
                else:
                    logger.warning(f"Assistant message had no text content for thread {thread_id}, but charts might be present.", extra={"thread_id": thread_id})
                    assistant_message_content = "" # Ensure it's an empty string if no text

            # 7. Update conversation history (HistoryService)
            execution_time, execution_time_seconds = get_execution_time(start_time)

            assistant_chat_message = ChatMessage(
                role="assistant",
                content=assistant_message_content,
                timestamp=get_utc_now(),
                execution_time=execution_time,
                execution_time_seconds=execution_time_seconds,
                charts=charts if charts else None
            )

            current_conversation_messages = previous_messages + [user_chat_message, assistant_chat_message]

            if history_id:
                updated_history_id = await history_service.update_history_messages( # Use history_service instance
                    history_id=history_id,
                    messages=current_conversation_messages,
                    file_used=current_chat_blob_path, # The blob name (full path) of the file actually used in this chat turn
                    user_id=user_id,
                    thread_id=thread_id,
                    openai_file_id=current_openai_file_id # The OpenAI File ID actually used/reused
                )
                if not updated_history_id:
                    logger.error(f"Failed to update history {history_id}. Falling back to create new history.", extra={"history_id": history_id})
                    updated_history_id = await history_service.create_history( # Use history_service instance
                        current_conversation_messages,
                        current_chat_blob_path,
                        user_id,
                        thread_id,
                        current_openai_file_id
                    )
            else:
                updated_history_id = await history_service.create_history( # Use history_service instance
                    current_conversation_messages,
                    current_chat_blob_path,
                    user_id,
                    thread_id,
                    current_openai_file_id
                )

            if not updated_history_id:
                logger.critical("Failed to create or update history item. This conversation will not be saved.",
                                 extra={"user_id": user_id, "thread_id": thread_id, "blob_path": current_chat_blob_path})
                # If history cannot be saved, we should still return the chat response
                # but ensure history_id is None to reflect no history was saved/updated.
                updated_history_id = None

            return ChatResponse(
                message=assistant_message_content,
                execution_time=execution_time,
                execution_time_seconds=execution_time_seconds,
                timestamp=get_utc_now(),
                history_id=updated_history_id,
                file_used=current_chat_blob_path, # Return the file that was actually used (full blob path)
                charts=charts if charts else None
            )

        except openai.OpenAIError as e:
            logger.error(f"OpenAI API error during chat processing: {str(e)}", exc_info=True,
                             extra={"thread_id": thread_id, "history_id": history_id, "file_blob_name": file_blob_name})
            error_detail = "An unknown OpenAI API error occurred."
            # Attempt to parse error detail from OpenAI's response
            if hasattr(e, 'response') and e.response:
                try:
                    error_json = e.response.json()
                    error_detail = error_json.get('error', {}).get('message', json.dumps(error_json))
                except json.JSONDecodeError:
                    error_detail = e.response.text
            elif hasattr(e, 'message'): # For older SDK versions or different error types
                error_detail = e.message

            raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"OpenAI API error: {error_detail}")
        except HTTPException:
            raise # Re-raise HTTP exceptions explicitly
        except Exception as e:
            logger.error(f"An unexpected error occurred during chat processing: {str(e)}", exc_info=True,
                             extra={"thread_id": thread_id, "history_id": history_id, "file_blob_name": file_blob_name, "user_id": user_id})
            raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"An internal server error occurred: {str(e)}")

    async def _create_thread(self) -> Thread:
        """
        Create a new OpenAI Assistant thread.
        """
        try:
            thread = self.client.beta.threads.create()
            logger.debug(f"OpenAI thread created: {thread.id}", extra={"thread_id": thread.id})
            return thread
        except Exception as e:
            logger.error(f"Error creating OpenAI thread: {str(e)}", exc_info=True)
            raise

    async def _add_message_to_thread(self, thread_id: str, role: str, content: str, file_ids: Optional[List[str]] = None) -> Message:
        """
        Add a message to an OpenAI Assistant thread.
        Uses the 'attachments' parameter for file handling as per latest OpenAI API.
        """
        try:
            attachments = []
            if file_ids:
                for file_id in file_ids:
                    # Each file ID should specify tools. Code Interpreter is common for data analysis files.
                    attachments.append({"file_id": file_id, "tools": [{"type": "code_interpreter"}]})

            message = self.client.beta.threads.messages.create(
                thread_id=thread_id,
                role=role,
                content=content,
                attachments=attachments
            )
            logger.debug(f"Message added to thread {thread_id}. Role: {role}, Content Length: {len(content)}, Attachments: {len(attachments) if attachments else 0}",
                              extra={"thread_id": thread_id, "role": role, "file_ids": file_ids})
            return message
        
        except Exception as e:
            logger.error(f"Error adding message to thread {thread_id}: {str(e)}", exc_info=True,
                              extra={"thread_id": thread_id, "role": role, "file_ids": file_ids})
            raise

    async def _add_file_to_thread(self, full_blob_name: str) -> Optional[str]:
        """
        Downloads a file from Azure Blob Storage using its full blob name,
        then uploads it to OpenAI for use with the Assistant.
        Returns the OpenAI file ID if successful, None otherwise.

        Args:
            full_blob_name: The complete path to the blob (e.g., 'files/user-abc/my_document.pdf').
        """
        try:
            logger.info(f"Attempting to download file from blob storage for OpenAI upload: {full_blob_name}", extra={"full_blob_name": full_blob_name})

            file_content_bytes = await blob_storage_manager.get_data_by_full_path(full_blob_name)

            if file_content_bytes is None:
                logger.error(f"Failed to download file content from blob storage for '{full_blob_name}'. It might not exist or be accessible.", extra={"full_blob_name": full_blob_name})
                return None

            file_stream = BytesIO(file_content_bytes)
            original_filename = os.path.basename(full_blob_name)

            logger.info(f"File '{original_filename}' downloaded to memory ({len(file_content_bytes)} bytes). Uploading to OpenAI.",
                              extra={"original_filename": original_filename, "file_size_bytes": len(file_content_bytes)})

            file = self.client.files.create(
                file=file_stream,
                purpose="assistants",
            )
            logger.info(f"File '{original_filename}' uploaded to OpenAI with ID: {file.id}", extra={"openai_file_id": file.id, "original_filename": original_filename})
            return file.id

        except Exception as e:
            logger.error(f"Error downloading or uploading file to OpenAI for blob '{full_blob_name}': {str(e)}", exc_info=True, extra={"full_blob_name": full_blob_name})
            return None

    async def _get_image_file_content_base64(self, file_id: str) -> Optional[str]:
        """
        Retrieves image file content from OpenAI and returns it as a base64 encoded string.
        """
        try:
            logger.debug(f"Attempting to retrieve image file content from OpenAI for file ID: {file_id}", extra={"openai_file_id": file_id})
            file_content_response = self.client.files.content(file_id)

            # OpenAI SDK's file content method can return various types, ensure it's bytes
            if isinstance(file_content_response, BytesIO):
                image_bytes = file_content_response.read()
            elif isinstance(file_content_response, bytes):
                image_bytes = file_content_response
            else:
                # Handle cases where it might be a response object with a content attribute
                if hasattr(file_content_response, 'content'):
                    image_bytes = file_content_response.content
                else:
                    logger.error(f"Unexpected type for OpenAI file content response for file ID {file_id}: {type(file_content_response)}", extra={"openai_file_id": file_id, "response_type": str(type(file_content_response))})
                    return None

            if not isinstance(image_bytes, bytes):
                logger.error(f"Image content for file ID {file_id} is not bytes. Actual type: {type(image_bytes)}", extra={"openai_file_id": file_id})
                return None

            base64_encoded_image = base64.b64encode(image_bytes).decode('utf-8')
            logger.debug(f"Successfully retrieved and base64 encoded image for file ID: {file_id}. Size: {len(image_bytes)} bytes", extra={"openai_file_id": file_id, "image_size_bytes": len(image_bytes)})
            return base64_encoded_image
        except Exception as e:
            logger.error(f"Error retrieving or encoding image file {file_id}: {str(e)}", exc_info=True, extra={"openai_file_id": file_id})
            return None

    async def _run_assistant(self, thread_id: str, assistant_id: str) -> Run:
        """
        Runs the OpenAI Assistant on a given thread.
        """
        try:
            run = self.client.beta.threads.runs.create(
                thread_id=thread_id,
                assistant_id=assistant_id
            )
            logger.debug(f"Assistant run initiated for thread {thread_id}, run ID: {run.id}", extra={"thread_id": thread_id, "run_id": run.id, "assistant_id": assistant_id})
            return run
        except Exception as e:
            logger.error(f"Error running assistant {assistant_id} on thread {thread_id}: {str(e)}", exc_info=True, extra={"thread_id": thread_id, "assistant_id": assistant_id})
            raise

    async def _wait_for_run(self, thread_id: str, run_id: str) -> Run:
        """
        Waits for an OpenAI Assistant run to complete.
        """
        try:
            logger.debug(f"Waiting for run {run_id} on thread {thread_id} to complete...", extra={"thread_id": thread_id, "run_id": run_id})
            while True:
                run = self.client.beta.threads.runs.retrieve(
                    thread_id=thread_id,
                    run_id=run_id
                )

                if run.status in ["completed", "failed", "cancelled", "expired"]:
                    break

                time.sleep(1) # Poll every 1 second

            if run.status == "failed":
                logger.error(f"Assistant run {run.id} failed for thread {thread_id}. Last error: {run.last_error}",
                                 extra={"thread_id": thread_id, "run_id": run.id, "run_status": run.status, "last_error": run.last_error.model_dump_json() if run.last_error else "N/A"}) # Added model_dump_json for logging
                error_message = getattr(run.last_error, 'message', "An unknown error occurred during assistant run.")
                raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Assistant run failed: {error_message}")

            logger.debug(f"Run {run.id} on thread {thread_id} completed with status: {run.status}", extra={"thread_id": thread_id, "run_id": run.id, "run_status": run.status})
            return run
        except HTTPException:
            raise # Re-raise HTTP exceptions
        except Exception as e:
            logger.error(f"Error waiting for run {run_id} on thread {thread_id}: {str(e)}", exc_info=True,
                              extra={"thread_id": thread_id, "run_id": run_id})
            raise

    async def _get_thread_messages(self, thread_id: str) -> Any:
        """
        Retrieves messages from an OpenAI Assistant thread.
        Note: OpenAI's `list` method returns messages in reverse chronological order by default (newest first).
        """
        try:
            messages_page = self.client.beta.threads.messages.list(
                thread_id=thread_id,
                order="desc" # Newest messages first (convenient for finding assistant message)
            )
            logger.debug(f"Retrieved {len(messages_page.data)} messages for thread {thread_id}.", extra={"thread_id": thread_id, "message_count": len(messages_page.data)})
            return messages_page
        except Exception as e:
            logger.error(f"Error getting thread messages for thread {thread_id}: {str(e)}", exc_info=True, extra={"thread_id": thread_id})
            raise