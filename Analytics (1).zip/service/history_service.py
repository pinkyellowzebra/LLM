import logging
from typing import List, Optional, Any, Dict # Any를 임포트합니다.

from fastapi import HTTPException, status

from models.history_model import HistoryManager
from models.schemas import HistoryItem, HistoryListResponse, ChatMessage

# ====================================================================
# 핵심 변경: ChatService 임포트 라인을 제거합니다.
# from service.chat_service import ChatService # 이 줄을 삭제하거나 주석 처리하세요.
# ====================================================================

logger = logging.getLogger(__name__)

class HistoryService:
    """
    대화 기록 관련 작업을 처리하는 서비스입니다.
    """

    # ====================================================================
    # 핵심 변경: chat_service 매개변수의 타입 힌트를 'ChatService' 대신 'Any'로 변경합니다.
    # 이는 ChatService를 직접 임포트하지 않아도 되게 합니다.
    def __init__(self, chat_service: Any):
        self.chat_service = chat_service
        logger.info("HistoryService 인스턴스가 생성되었습니다.")
    # ====================================================================

    async def create_history(
        self,
        messages: List[ChatMessage],
        file_used: Optional[str] = None,
        user_id: Optional[str] = None,
        thread_id: Optional[str] = None,
        openai_file_id: Optional[str] = None
    ) -> str:
        """
        새로운 대화 기록 항목을 생성합니다.
        """
        try:
            history_item = await HistoryManager.create_new_history_item(
                messages=messages,
                file_used=file_used,
                user_id=user_id,
                thread_id=thread_id,
                openai_file_id=openai_file_id
            )
            logger.info(f"새로운 기록이 성공적으로 생성되었습니다: {history_item.history_id}", extra={"history_id": history_item.history_id, "user_id": user_id})
            return history_item.history_id
        except Exception as e:
            logger.error(f"기록 생성 중 오류 발생: {str(e)}", exc_info=True, extra={"user_id": user_id})
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"새 대화 기록을 생성하는 중 오류 발생: {str(e)}"
            )

    async def get_history(self, history_id: str, user_id: Optional[str] = None) -> HistoryItem:
        """
        ID를 사용하여 대화 기록 항목을 가져옵니다.
        사용자 ID가 제공되면 해당 사용자의 기록만 조회하고, 권한이 없는 경우 HTTPException을 발생시킵니다.
        """
        try:
            history_item = await HistoryManager.get_history(history_id)
            if not history_item:
                logger.warning(f"기록 {history_id}를 찾을 수 없습니다.", extra={"history_id": history_id, "requested_by_user": user_id})
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"기록 항목 {history_id}를 찾을 수 없습니다."
                )

            # 소유권 확인 로직 (user_id가 제공된 경우)
            if user_id and history_item.user_id and history_item.user_id != user_id:
                logger.warning(f"사용자 {user_id}가 소유자 {history_item.user_id}의 기록 {history_id}에 접근하려 시도했습니다. 권한 거부됨.",
                               extra={"history_id": history_id, "requested_by_user": user_id, "owner_user_id": history_item.user_id})
                # 보안상 403 대신 404를 반환하여 다른 사용자의 기록 존재 여부를 유추하기 어렵게 할 수 있습니다.
                # 여기서는 명시적인 403을 사용하여 '권한 없음'을 알립니다.
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="이 기록에 접근할 권한이 없습니다."
                )
            
            logger.info(f"기록 {history_id}가 성공적으로 조회되었습니다 (요청 사용자: {user_id if user_id else '비인증'}).", extra={"history_id": history_id, "requested_by_user": user_id})
            return history_item
        except HTTPException:
            raise # 이미 HTTPException이 발생했으므로 그대로 다시 발생
        except Exception as e:
            logger.error(f"기록 {history_id}를 가져오는 중 오류 발생: {str(e)}", exc_info=True, extra={"history_id": history_id, "requested_by_user": user_id})
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"대화 기록을 가져오는 중 오류 발생: {str(e)}"
            )

    async def update_history_messages(
        self,
        history_id: str,
        messages: List[ChatMessage],
        file_used: Optional[str] = None,
        user_id: Optional[str] = None,
        thread_id: Optional[str] = None,
        openai_file_id: Optional[str] = None
    ) -> str: # Optional[str] 대신 str 반환으로 변경 (성공 시 ID 반환, 실패 시 예외)
        """
        기존 대화 기록 항목의 메시지 목록을 업데이트합니다.
        """
        try:
            current_history_item = await HistoryManager.get_history(history_id)
            if not current_history_item:
                logger.warning(f"존재하지 않는 기록 {history_id}를 업데이트하려 시도했습니다.", extra={"history_id": history_id})
                raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"대화 기록 {history_id}를 찾을 수 없습니다.")

            # 소유권 확인
            if user_id and current_history_item.user_id and current_history_item.user_id != user_id:
                logger.warning(f"사용자 {user_id}가 사용자 {current_history_item.user_id}의 기록 {history_id}를 업데이트하려 시도했습니다. 권한 거부됨.",
                               extra={"history_id": history_id, "requested_by_user": user_id, "owner_user_id": current_history_item.user_id})
                raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="이 대화 기록을 업데이트할 권한이 없습니다.")

            # 메시지 목록을 통합 (기존 메시지에 새 메시지 추가)
            updated_messages = current_history_item.messages + messages

            updated_history_item = await HistoryManager.update_history_item(
                history_id=history_id,
                messages=updated_messages,
                file_used=file_used if file_used is not None else current_history_item.file_used,
                user_id=user_id if user_id is not None else current_history_item.user_id,
                thread_id=thread_id if thread_id is not None else current_history_item.thread_id,
                openai_file_id=openai_file_id if openai_file_id is not None else current_history_item.openai_file_id
            )

            if updated_history_item:
                logger.info(f"기록 {history_id}의 메시지가 성공적으로 업데이트되었습니다.", extra={"history_id": history_id})
                return updated_history_item.history_id
            else:
                logger.error(f"기록 {history_id}의 메시지 업데이트에 실패했습니다. HistoryManager에서 None 반환.", extra={"history_id": history_id})
                raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"대화 기록 {history_id} 업데이트에 실패했습니다.")
        except HTTPException:
            raise
        except Exception as e:
            logger.error(f"기록 {history_id}의 메시지를 업데이트하는 중 오류 발생: {str(e)}", exc_info=True, extra={"history_id": history_id, "requested_by_user": user_id})
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"대화 기록을 업데이트하는 중 오류 발생: {str(e)}"
            )

    async def list_history(self, user_id: Optional[str] = None) -> HistoryListResponse:
        """
        대화 기록 항목 목록을 조회합니다. user_id가 제공되면 해당 사용자의 기록만 조회합니다.
        """
        try:
            history_items = await HistoryManager.list_history_blobs(user_id)
            logger.info(f"사용자 {user_id if user_id else '모든 사용자'}에 대해 {len(history_items)}개의 기록 항목이 조회되었습니다.",
                                 extra={"user_id": user_id, "item_count": len(history_items)})
            return HistoryListResponse(history_items=history_items)
        except Exception as e:
            logger.error(f"기록 목록 조회 중 오류 발생: {str(e)}", exc_info=True, extra={"user_id": user_id})
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"대화 기록 목록을 조회하는 중 오류 발생: {str(e)}"
            )

    async def delete_history(
        self,
        history_id: str,
        user_id: Optional[str] = None,
    ) -> bool:
        """
        대화 기록 항목과 관련된 Azure Blob Storage 파일, OpenAI 스레드 및 파일을 삭제합니다.
        성공 시 True를 반환하고, 실패 시 HTTPException을 발생시킵니다.
        """
        logger.info(f"기록 {history_id} 삭제 시도 (요청 사용자: {user_id})", extra={"history_id": history_id, "requested_by_user": user_id})

        try:
            # 1. 먼저 HistoryItem을 가져와 관련 정보를 확인하고 소유권을 확인합니다.
            history_item = await self.get_history(history_id, user_id) 

            # 2. Azure Blob Storage에서 기록 파일 삭제 (가장 중요)
            delete_blob_success = await HistoryManager.delete_history_blob(history_id, user_id=history_item.user_id)

            if not delete_blob_success:
                logger.error(f"Azure Blob Storage에서 기록 블롭 {history_id} 삭제에 실패했습니다.", extra={"history_id": history_id})
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"기록 {history_id}의 Azure Blob Storage 파일 삭제에 실패했습니다."
                )

            logger.info(f"Azure Blob Storage에서 기록 블롭 {history_id}가 성공적으로 삭제되었습니다.", extra={"history_id": history_id})

            # 3. OpenAI Assistants API에서 관련 Thread 삭제
            if history_item.thread_id:
                try:
                    logger.info(f"관련된 OpenAI 스레드 {history_item.thread_id}를 삭제하려 시도합니다.", extra={"thread_id": history_item.thread_id})
                    await self.chat_service.delete_thread(history_item.thread_id)
                    logger.info(f"OpenAI 스레드 {history_item.thread_id}가 성공적으로 삭제되었습니다.", extra={"thread_id": history_item.thread_id})
                except Exception as e:
                    logger.warning(f"OpenAI 스레드 {history_item.thread_id} 삭제 중 오류 발생: {str(e)}", exc_info=True, extra={"thread_id": history_item.thread_id})
                    # 스레드 삭제 실패는 치명적이지 않다고 판단하여 경고만 로깅하고 삭제 프로세스를 계속 진행
            else:
                logger.info(f"기록 {history_id}에 삭제할 관련된 OpenAI 스레드가 없습니다.", extra={"history_id": history_id})

            # 4. OpenAI Assistants API에서 관련 File 삭제
            if history_item.openai_file_id:
                try:
                    logger.info(f"관련된 OpenAI 파일 {history_item.openai_file_id}를 삭제하려 시도합니다.", extra={"openai_file_id": history_item.openai_file_id})
                    await self.chat_service.delete_file(history_item.openai_file_id)
                    logger.info(f"OpenAI 파일 {history_item.openai_file_id}가 성공적으로 삭제되었습니다.", extra={"openai_file_id": history_item.openai_file_id})
                except Exception as e:
                    logger.warning(f"OpenAI 파일 {history_item.openai_file_id} 삭제 중 오류 발생: {str(e)}", exc_info=True, extra={"openai_file_id": history_item.openai_file_id})
                    # 파일 삭제 실패도 치명적이지 않다고 판단하여 경고만 로깅하고 삭제 프로세스를 계속 진행
            else:
                logger.info(f"기록 {history_id}에 삭제할 관련된 OpenAI 파일이 없습니다.", extra={"history_id": history_id})
            
            logger.info(f"기록 {history_id} 및 모든 관련 리소스 삭제 시도 완료.", extra={"history_id": history_id})
            return True # 모든 삭제 시도가 성공적으로 완료되었음을 나타냄

        except HTTPException:
            raise # get_history에서 발생한 HTTPException은 그대로 다시 발생
        except Exception as e:
            logger.error(f"기록 {history_id}의 전체 삭제 중 예상치 못한 오류 발생: {str(e)}", exc_info=True, extra={"history_id": history_id, "requested_by_user": user_id})
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"기록 삭제 중 서버 오류 발생: {str(e)}"
            )