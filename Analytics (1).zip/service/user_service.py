import os
import logging
import jwt
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List

from fastapi import HTTPException # Depends는 UserService 클래스 내에서는 직접 사용되지 않습니다.
# from fastapi.security import OAuth2PasswordBearer # <-- 이 줄은 api/deps.py나 user_routes.py로 이동해야 합니다.

# user_model에서 UserManager를, schemas에서 Pydantic 모델들을 가져옵니다.
from models.user_model import UserManager # UserCreate는 schemas에서 다시 임포트
from models.schemas import UserCreate, UserLogin, UserResponse, TokenResponse 
# JWT_SECRET_KEY, JWT_ALGORITHM, JWT_EXPIRATION_MINUTES를 settings에서 가져옵니다.
from config.settings import JWT_SECRET_KEY, JWT_ALGORITHM, JWT_EXPIRATION_MINUTES

logger = logging.getLogger(__name__)

 

class UserService:
    """
    Service for handling user operations
    """
    
    @staticmethod
    async def register_user(user_data: UserCreate) -> UserResponse:
        """
        Register a new user.
        """
        logger.info(f"Registering user: {user_data.username}")
        try:
            # Create the user using UserManager
            user = await UserManager.create_user(
                username=user_data.username,
                password=user_data.password
            )
            
            # Return the user data as UserResponse Pydantic model
            return UserResponse(
                id=user["id"],
                username=user["username"],
                created_at=user["created_at"],
                last_login=user["last_login"]
            )
        except ValueError as e:
            # Handle validation errors (e.g., username already exists)
            raise HTTPException(status_code=400, detail=str(e))
        except Exception as e:
            logger.error(f"Error registering user: {str(e)}", exc_info=True)
            raise HTTPException(status_code=500, detail=f"An unexpected error occurred during registration: {str(e)}")
    
    @staticmethod
    async def login_user(login_data: UserLogin) -> TokenResponse:
        """
        Authenticate a user and return a JWT token.
        Expects a UserLogin Pydantic model.
        """
        try:
            # Authenticate the user using UserManager
            # UserManager.authenticate_user should return the user dict or None
            user = await UserManager.authenticate_user(
                username=login_data.username,
                password=login_data.password
            )
            
            if not user:
                raise HTTPException(
                    status_code=401,
                    detail="Invalid username or password",
                    headers={"WWW-Authenticate": "Bearer"},
                )
            
            # Create access token using the static method
            access_token = UserService.create_access_token(
                data={"sub": str(user["id"]), "username": user["username"]} # 'sub' should typically be a string
            )
            
            # Return the token and user data
            return TokenResponse(
                access_token=access_token,
                token_type="bearer",
                user=UserResponse(
                    id=user["id"],
                    username=user["username"],
                    created_at=user["created_at"],
                    last_login=user["last_login"]
                )
            )
        except HTTPException:
            # Re-raise HTTP exceptions (e.g., 401 from above)
            raise
        except Exception as e:
            logger.error(f"Error logging in user: {str(e)}", exc_info=True)
            raise HTTPException(status_code=500, detail=f"An unexpected error occurred during login: {str(e)}")
    
    @staticmethod
    def create_access_token(data: Dict[str, Any]) -> str:
        """
        Create a JWT access token.
        """
        to_encode = data.copy()
        # JWT_EXPIRATION_MINUTES를 사용하여 만료 시간 설정
        expire = datetime.utcnow() + timedelta(minutes=JWT_EXPIRATION_MINUTES)
        to_encode.update({"exp": expire})
        
        return jwt.encode(to_encode, JWT_SECRET_KEY, algorithm=JWT_ALGORITHM)

    @staticmethod
    async def get_current_user_from_token(token: str) -> Dict[str, Any]:
        """
        Get the current authenticated user from the JWT token.
        This method is meant to be used by the dependency in api/deps.py,
        not directly as a UserService method called from routes.
        """
        try:
            payload = jwt.decode(token, JWT_SECRET_KEY, algorithms=[JWT_ALGORITHM])
            user_id: str = payload.get("sub") # user id is typically a string in JWT sub claim
            username: str = payload.get("username") # Also get username from token

            if user_id is None or username is None:
                raise HTTPException(
                    status_code=401,
                    detail="Invalid authentication credentials",
                    headers={"WWW-Authenticate": "Bearer"},
                )
            
            # Get the user from the database to ensure it's still valid and get full data
            user = await UserManager.get_user_by_id(user_id) # Assuming UserManager.get_user_by_id exists
            
            if user is None:
                raise HTTPException(
                    status_code=401,
                    detail="User not found",
                    headers={"WWW-Authenticate": "Bearer"},
                )
            
            # Return the user data (excluding sensitive info like password hash)
            if "password_hash" in user:
                del user["password_hash"]
            
            return user
        except jwt.PyJWTError:
            raise HTTPException(
                status_code=401,
                detail="Invalid authentication credentials",
                headers={"WWW-Authenticate": "Bearer"},
            )
        except Exception as e:
            logger.error(f"Error getting current user: {str(e)}", exc_info=True)
            raise HTTPException(status_code=500, detail=f"An unexpected error occurred while getting current user: {str(e)}")
    
    @staticmethod
    async def list_users() -> List[UserResponse]:
        """
        List all users.
        """
        try:
            users = await UserManager.list_users() # UserManager.list_users should return a list of user dicts
            
            # Convert each user dict to UserResponse Pydantic model
            return [
                UserResponse(
                    id=user["id"],
                    username=user["username"],
                    created_at=user["created_at"],
                    last_login=user["last_login"]
                )
                for user in users
            ]
        except Exception as e:
            logger.error(f"Error listing users: {str(e)}", exc_info=True)
            raise HTTPException(status_code=500, detail=f"An unexpected error occurred while listing users: {str(e)}")

    # NOTE: get_user_by_id는 UserManager에 직접 두는 것이 더 적절합니다.
    # UserService는 비즈니스 로직을 다루고, UserManager는 DB 접근 로직을 다룹니다.
    # 만약 UserManager에 get_user_by_id가 없다면 추가해야 합니다.
    # 