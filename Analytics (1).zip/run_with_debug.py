import os
import logging
import uvicorn
import sys
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

# Configure logging to file
logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler("app_debug.log"),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)
logger.info("Starting application with debug logging")

def run_app():
    """Run the FastAPI application with debug settings"""
    try:
        # Print startup message
        print("\n" + "="*80)
        print(" RUNNING APPLICATION WITH AUTHENTICATION DISABLED FOR TESTING")
        print(" WARNING: Do not use this configuration in production!")
        print("="*80)
        print("\n Authentication has been disabled for the following endpoints:")
        print(" - /api/files/upload")
        print(" - /api/chat/message")
        print("\n Access the Swagger UI at: http://127.0.0.1:8080/api/docs")
        print("\n Press Ctrl+C to stop the server")
        print("="*80 + "\n")
        
        # Set environment variables for debugging
        os.environ["DEBUG_MODE"] = "True"
        
        # Import the app after setting environment variables
        from main_v0 import app
        
        # Disable authentication for Swagger UI
        app.swagger_ui_init_oauth = None
        
        # Run the server
        logger.info("Starting server on http://127.0.0.1:8080")
        uvicorn.run(
            app,
            host="127.0.0.1",
            port=8080,
            reload=True,
            log_level="debug",
        )
    except Exception as e:
        logger.error(f"Error starting server: {str(e)}", exc_info=True)

if __name__ == "__main__":
    run_app()
