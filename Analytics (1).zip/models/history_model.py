import logging
import json
from datetime import datetime, timezone
from typing import List, Optional, Dict, Any
import uuid
import os

from models.schemas import HistoryItem, ChatMessage
from utils.blob_utils import blob_storage_manager
from config.settings import BLOB_FOLDER_HISTORY

logger = logging.getLogger(__name__)

class HistoryManager:
    """
    Manages the storage and retrieval of chat history data in Azure Blob Storage.
    All methods leverage the user_id to ensure user-isolated folder structures
    in conjunction with the blob_storage_manager.
    """

    @staticmethod
    async def create_new_history_item(
        messages: List[ChatMessage],
        user_id: Optional[str] = None,
        file_used: Optional[str] = None,
        openai_file_id: Optional[str] = None,
        thread_id: Optional[str] = None
    ) -> HistoryItem:
        """
        Creates a new chat history item and saves it to Azure Blob Storage.
        Raises an exception if an error occurs during the process.
        """
        new_history_id = str(uuid.uuid4())
        timestamp_utc = datetime.now(timezone.utc)

        history_item = HistoryItem(
            history_id=new_history_id,
            timestamp=timestamp_utc,
            messages=messages,
            file_used=file_used,
            openai_file_id=openai_file_id,
            user_id=user_id,
            thread_id=thread_id
        )

        history_json_bytes = history_item.model_dump_json(indent=2).encode('utf-8')

        blob_name_base = f"{new_history_id}.json"

        metadata_to_save = {
            "user_id": user_id,
            "openai_file_id": openai_file_id,
            "thread_id": thread_id,
            "original_filename": file_used,
            "timestamp": timestamp_utc.isoformat()
        }
        metadata_to_save = {k: str(v) for k, v in metadata_to_save.items() if v is not None}

        try:
            await blob_storage_manager.save_data(
                folder=BLOB_FOLDER_HISTORY,
                blob_name=blob_name_base,
                data=history_json_bytes,
                content_type="application/json",
                user_id=user_id,
                metadata=metadata_to_save
            )
            logger.info(
                f"New history item {new_history_id} created and saved for user {user_id}.",
                extra={"history_id": new_history_id, "user_id": user_id}
            )
            return history_item
        except Exception as e:
            logger.error(
                f"Error creating and saving new history item: {str(e)}",
                exc_info=True,
                extra={"user_id": user_id}
            )
            raise

    @staticmethod
    async def get_history(history_id: str, user_id: Optional[str] = None) -> Optional[HistoryItem]:
        """
        Retrieves chat history data corresponding to the history_id from Azure Blob Storage
        and returns it as a HistoryItem object. If user_id is provided, it efficiently
        searches within that user's folder.

        Args:
            history_id: The ID (UUID) of the conversation history to retrieve.
            user_id: The ID of the history item's owner (optional).

        Returns:
            Optional[HistoryItem]: The HistoryItem object, or None if not found.
        """
        blob_name_base = f"{history_id}.json"

        try:
            raw_history_data = await blob_storage_manager.get_data(
                folder=BLOB_FOLDER_HISTORY,
                blob_name=blob_name_base,
                user_id=user_id
            )

            if raw_history_data:
                history_dict = json.loads(raw_history_data.decode('utf-8'))
                history_item = HistoryItem(**history_dict)

                logger.info(
                    f"History {history_id} (user: {user_id if user_id else 'all users'}) successfully retrieved.",
                    extra={"history_id": history_id, "user_id": user_id}
                )
                return history_item
            else:
                logger.info(
                    f"History {history_id} (user: {user_id if user_id else 'all users'}) not found in Blob Storage.",
                    extra={"history_id": history_id, "user_id": user_id}
                )
                return None
        except Exception as e:
            logger.error(
                f"Error retrieving history {history_id} (user: {user_id if user_id else 'all users'}): {str(e)}",
                exc_info=True,
                extra={"history_id": history_id, "user_id": user_id}
            )
            raise

    @staticmethod
    async def update_history_item(
        history_id: str,
        messages: List[ChatMessage],
        user_id: Optional[str] = None,
        file_used: Optional[str] = None,
        openai_file_id: Optional[str] = None,
        thread_id: Optional[str] = None
    ) -> Optional[HistoryItem]:
        """
        Updates an existing chat history item and saves it to Azure Blob Storage.
        Raises an exception if an error occurs during the process.
        """
        timestamp_utc = datetime.now(timezone.utc)

        history_item = HistoryItem(
            history_id=history_id,
            timestamp=timestamp_utc,
            messages=messages,
            file_used=file_used,
            openai_file_id=openai_file_id,
            user_id=user_id,
            thread_id=thread_id
        )

        history_json_bytes = history_item.model_dump_json(indent=2).encode('utf-8')

        blob_name_base = f"{history_id}.json"

        metadata_to_save = {
            "user_id": user_id,
            "openai_file_id": openai_file_id,
            "thread_id": thread_id,
            "original_filename": file_used,
            "timestamp": timestamp_utc.isoformat()
        }
        metadata_to_save = {k: str(v) for k, v in metadata_to_save.items() if v is not None}

        try:
            await blob_storage_manager.save_data(
                folder=BLOB_FOLDER_HISTORY,
                blob_name=blob_name_base,
                data=history_json_bytes,
                content_type="application/json",
                user_id=user_id,
                metadata=metadata_to_save
            )
            logger.info(
                f"History item {history_id} successfully updated for user {user_id}.",
                extra={"history_id": history_id, "user_id": user_id}
            )
            return history_item
        except Exception as e:
            logger.error(
                f"Error updating history item {history_id}: {str(e)}",
                exc_info=True,
                extra={"history_id": history_id, "user_id": user_id}
            )
            raise

    @staticmethod
    async def list_history_blobs(user_id: Optional[str] = None) -> List[HistoryItem]:
        """
        Retrieves a list of chat history blobs for a specific user or all users
        from Azure Blob Storage. Converts the retrieved blob information into
        a list of HistoryItem objects. This function populates HistoryItem
        using only metadata without loading the full blob content.
        """
        try:
            listed_blob_infos = await blob_storage_manager.list_blobs_in_folder(
                folder=BLOB_FOLDER_HISTORY,
                user_id=user_id
            )

            history_items = []
            for blob_info in listed_blob_infos:
                full_blob_path = blob_info.get("name")
                if full_blob_path:
                    try:
                        properties = blob_info.get("properties", {})
                        metadata = properties.get("metadata", {})

                        history_id_from_name = os.path.basename(full_blob_path).replace(".json", "")

                        history_timestamp_str = metadata.get("timestamp")
                        if not history_timestamp_str and properties.get("creation_time"):
                            history_timestamp_str = properties.get("creation_time").isoformat()

                        history_items.append(
                            HistoryItem(
                                history_id=history_id_from_name,
                                timestamp=history_timestamp_str,
                                messages=[],
                                file_used=metadata.get("original_filename"),
                                openai_file_id=metadata.get("openai_file_id"),
                                user_id=metadata.get("user_id"),
                                thread_id=metadata.get("thread_id")
                            )
                        )
                    except Exception as e:
                        logger.warning(
                            f"Error parsing blob information for {full_blob_path}: {str(e)}",
                            exc_info=True,
                            extra={"blob_path": full_blob_path, "user_id": user_id}
                        )
                        continue

            logger.info(
                f"Listed {len(history_items)} history blobs for user '{user_id if user_id else 'all users'}'",
                extra={"user_id": user_id, "item_count": len(history_items)}
            )
            return history_items
        except Exception as e:
            logger.error(
                f"Error listing history blobs: {str(e)}",
                exc_info=True,
                extra={"user_id": user_id}
            )
            raise

    @staticmethod
    async def delete_history_blob(history_id: str, user_id: Optional[str] = None) -> bool:
        """
        Deletes a specific chat history blob from Azure Blob Storage.
        Returns True on successful deletion, False if not found or deletion fails.
        """
        blob_name_in_folder = f"{history_id}.json"

        try:
            delete_success = await blob_storage_manager.delete_file(
                folder=BLOB_FOLDER_HISTORY,
                blob_name=blob_name_in_folder,
                user_id=user_id
            )
            if delete_success:
                logger.info(
                    f"History blob ({BLOB_FOLDER_HISTORY}/{user_id}/{blob_name_in_folder}) successfully deleted from Blob Storage.",
                    extra={"history_id": history_id, "user_id": user_id}
                )
            else:
                logger.warning(
                    f"Failed to delete history blob ({BLOB_FOLDER_HISTORY}/{user_id}/{blob_name_in_folder}) from Blob Storage (not found or error).",
                    extra={"history_id": history_id, "user_id": user_id}
                )
            return delete_success
        except Exception as e:
            logger.error(
                f"Error deleting history blob ({BLOB_FOLDER_HISTORY}/{user_id}/{blob_name_in_folder}) from Blob Storage: {str(e)}",
                exc_info=True,
                extra={"history_id": history_id, "user_id": user_id}
            )
            raise