import logging
import uuid
# import hashlib # Unused - Removed
import json
from typing import Optional, Dict, Any, List
from pydantic import BaseModel, Field
from datetime import datetime
# bcrypt를 위해 passlib를 임포트합니다.
# 설치 필요: pip install "passlib[bcrypt]"
from passlib.context import CryptContext

from utils.blob_utils import blob_storage_manager
from utils.time_utils import get_utc_now
from config.settings import BLOB_FOLDER_USERS
from pydantic_core import to_jsonable_python # 사용은 되지만, datetime 처리 방식 변경으로 불필요할 수 있음

logger = logging.getLogger(__name__)

# 비밀번호 해싱 컨텍스트 설정
# bcrypt는 보안이 강화된 해싱 알고리즘입니다.
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# Request model for user creation
class UserCreate(BaseModel):
    """Request model for user creation"""
    username: str = Field(..., description="The username for the new user")
    password: str = Field(..., description="The password for the new user")

# Response model for user information
class UserResponse(BaseModel):
    """Response model for user information"""
    id: str
    username: str
    created_at: datetime
    last_login: datetime

# Response model for authentication token
class TokenResponse(BaseModel):
    """Response model for authentication token"""
    access_token: str = Field(..., description="The JWT access token")
    token_type: str = Field("bearer", description="The token type")
    user: UserResponse = Field(..., description="The user information")

class UserManager:
    """
    Manages user accounts, including registration, authentication, and profile management.
    """
    
    @staticmethod
    async def create_user(username: str, password: str) -> Dict[str, Any]:
        """
        Create a new user account.
        Returns the user data including the user ID.
        """
        logger.debug(f"Attempting to create user: '{username}'")
        try:
            # Check if username already exists
            existing_user = await UserManager.get_user_by_username(username)
            if existing_user:
                logger.warning(f"Username '{username}' already exists. Raising ValueError.")
                raise ValueError(f"Username '{username}' already exists")
            
            # Generate a unique user ID
            user_id = str(uuid.uuid4())
            
            # Hash the password using bcrypt
            hashed_password = UserManager._hash_password(password)
            
            # Create user data
            # --- 수정된 부분: datetime 객체를 ISO 8601 문자열로 변환 ---
            user_data = {
                "id": user_id,
                "username": username,
                "password_hash": hashed_password,
                "created_at": get_utc_now().isoformat(), # datetime을 문자열로 변환
                "last_login": get_utc_now().isoformat()  # datetime을 문자열로 변환
            }
            # pydantic_core.to_jsonable_python은 Pydantic 모델 인스턴스에 유용하지만,
            # 이미 dict 내부의 datetime을 문자열로 변환했으므로 여기서는 직접 dumps 사용
            # json_serializable_user_data = to_jsonable_python(user_data) # 이 줄은 이제 불필요
            serialized_user_data_bytes = json.dumps(user_data, ensure_ascii=False).encode('utf-8')
            # -------------------------------------------------------------

            # Save to blob storage
            blob_name = f"user_{user_id}.json" 
            
            await blob_storage_manager.save_data(
                folder=BLOB_FOLDER_USERS,
                blob_name=blob_name,
                data=serialized_user_data_bytes,
                content_type="application/json"
            )
            logger.info(f"User '{username}' (ID: {user_id}) created and saved to blob: {BLOB_FOLDER_USERS}/{blob_name}")
            
            # Return user data (without password hash) - 여기서는 datetime 객체로 다시 변환하여 UserResponse에 맞춥니다.
            # API 응답 모델에 맞게 datetime 객체로 다시 변환
            return {
                "id": user_id,
                "username": username,
                "created_at": datetime.fromisoformat(user_data["created_at"]),
                "last_login": datetime.fromisoformat(user_data["last_login"])
            }
        except ValueError as e: 
            raise
        except Exception as e:
            logger.error(f"Error creating user '{username}': {str(e)}", exc_info=True)
            raise 
    
    @staticmethod
    async def authenticate_user(username: str, password: str) -> Optional[Dict[str, Any]]:
        """
        Authenticate a user with username and password.
        Returns the user data if authentication is successful, None otherwise.
        """
        logger.debug(f"Attempting to authenticate user: '{username}'")
        try:
            # Get user by username
            user_data = await UserManager.get_user_by_username(username)
            
            if not user_data:
                logger.info(f"Authentication failed: User '{username}' not found.")
                return None
            
            # Verify password using bcrypt
            if not UserManager._verify_password(password, user_data.get("password_hash")):
                logger.info(f"Authentication failed: Invalid password for user '{username}'.")
                return None
            
            logger.info(f"User '{username}' authenticated successfully.")
            
            # Update last login time
            # --- 수정된 부분: datetime 객체를 ISO 8601 문자열로 변환 ---
            user_data["last_login"] = get_utc_now().isoformat() # datetime을 문자열로 변환
            # -------------------------------------------------------------
            if isinstance(user_data.get("created_at"), datetime):
                user_data["created_at"] = user_data["created_at"].isoformat()
            # -------------------------------------------------------------
            
            # Save updated user data
            blob_name = f"user_{user_data['id']}.json" 
            await blob_storage_manager.save_data(
                folder=BLOB_FOLDER_USERS,
                blob_name=blob_name,
                data=json.dumps(user_data, ensure_ascii=False).encode('utf-8'), # 이제 user_data 내 모든 datetime이 문자열
                content_type="application/json"
            )
            
            # Return user data (without password hash) - 여기서는 datetime 객체로 다시 변환하여 UserResponse에 맞춥니다.
            # API 응답 모델에 맞게 datetime 객체로 다시 변환
            return {
                "id": user_data["id"],
                "username": user_data["username"],
                "created_at": datetime.fromisoformat(user_data["created_at"]),
                "last_login": datetime.fromisoformat(user_data["last_login"])
            }
        except Exception as e:
            logger.error(f"Error authenticating user '{username}': {str(e)}", exc_info=True)
            return None
    
    @staticmethod
    async def get_user_by_id(user_id: str) -> Optional[Dict[str, Any]]:
        """
        Get a user by ID.
        """
        logger.debug(f"Attempting to get user by ID: '{user_id}'")
        try:
            blob_name = f"user_{user_id}.json"
            full_blob_path = f"{BLOB_FOLDER_USERS}/{blob_name}" 
            
            user_data_bytes = await blob_storage_manager.get_data_by_full_path(full_blob_path)
            
            if not user_data_bytes:
                logger.debug(f"User with ID '{user_id}' not found in blob storage.")
                return None
            
            # 바이트 데이터를 UTF-8로 디코딩 후 JSON 로드
            # --- 수정된 부분: 읽어온 데이터의 created_at, last_login을 datetime 객체로 변환 ---
            user_dict = json.loads(user_data_bytes.decode('utf-8'))
            if "created_at" in user_dict and isinstance(user_dict["created_at"], str):
                user_dict["created_at"] = datetime.fromisoformat(user_dict["created_at"])
            if "last_login" in user_dict and isinstance(user_dict["last_login"], str):
                user_dict["last_login"] = datetime.fromisoformat(user_dict["last_login"])
            return user_dict
            # ---------------------------------------------------------------------------------
        except Exception as e:
            logger.error(f"Error getting user by ID '{user_id}': {str(e)}", exc_info=True)
            return None
    
    @staticmethod
    async def get_user_by_username(username: str) -> Optional[Dict[str, Any]]:
        """
        Get a user by username.
        Iterates through all user blobs to find a match.
        """
        logger.debug(f"get_user_by_username: Searching for username: '{username}' (type: {type(username)}, len: {len(username)})")
        try:
            blobs = await blob_storage_manager.list_blobs_in_folder(
                folder=BLOB_FOLDER_USERS
            )
            logger.debug(f"get_user_by_username: Found {len(blobs)} blobs in folder '{BLOB_FOLDER_USERS}'.")
            
            for blob in blobs:
                blob_full_name = blob["name"] 
                logger.debug(f"get_user_by_username: Processing blob: '{blob_full_name}'")
                
                try:
                    user_data_bytes = await blob_storage_manager.get_data_by_full_path(blob_full_name) 
                    
                    if user_data_bytes:
                        # --- 수정된 부분: 읽어온 데이터의 created_at, last_login을 datetime 객체로 변환 ---
                        user_dict = json.loads(user_data_bytes.decode('utf-8'))
                        if "created_at" in user_dict and isinstance(user_dict["created_at"], str):
                            user_dict["created_at"] = datetime.fromisoformat(user_dict["created_at"])
                        if "last_login" in user_dict and isinstance(user_dict["last_login"], str):
                            user_dict["last_login"] = datetime.fromisoformat(user_dict["last_login"])
                        # ---------------------------------------------------------------------------------
                        
                        found_username_in_blob = user_dict.get("username")
                        logger.debug(f"get_user_by_username: Username in blob '{blob_full_name}': '{found_username_in_blob}' (type: {type(found_username_in_blob)}, len: {len(found_username_in_blob)})")
                        
                        if found_username_in_blob == username:
                            logger.info(f"get_user_by_username: User '{username}' found in blob '{blob_full_name}'.")
                            return user_dict
                        else:
                            logger.debug(f"get_user_by_username: Username mismatch: Looking for '{username}', found '{found_username_in_blob}' in '{blob_full_name}'")
                    else:
                        logger.debug(f"get_user_by_username: No data retrieved for blob: '{blob_full_name}'")
                except json.JSONDecodeError as jde:
                    logger.error(f"get_user_by_username: JSON Decode Error for blob '{blob_full_name}': {jde}")
                except UnicodeDecodeError as ude:
                    logger.error(f"get_user_by_username: Unicode Decode Error for blob '{blob_full_name}': {ude}")
                except Exception as e:
                    logger.error(f"get_user_by_username: Error processing user blob '{blob_full_name}': {str(e)}", exc_info=True)
            
            logger.info(f"get_user_by_username: User '{username}' not found after checking all blobs.")
            return None
        except Exception as e:
            logger.error(f"get_user_by_username: Error listing or processing blobs in folder '{BLOB_FOLDER_USERS}': {str(e)}", exc_info=True)
            return None
    
    @staticmethod
    async def list_users() -> List[Dict[str, Any]]:
        """
        List all users.
        """
        logger.debug("Attempting to list all users.")
        try:
            blobs = await blob_storage_manager.list_blobs_in_folder(
                folder=BLOB_FOLDER_USERS
            )
            
            users = []
            
            for blob in blobs:
                blob_full_name = blob["name"] 
                try:
                    user_data_bytes = await blob_storage_manager.get_data_by_full_path(blob_full_name) 
                    
                    if user_data_bytes:
                        # --- 수정된 부분: 읽어온 데이터의 created_at, last_login을 datetime 객체로 변환 ---
                        user_dict = json.loads(user_data_bytes.decode('utf-8'))
                        if "created_at" in user_dict and isinstance(user_dict["created_at"], str):
                            user_dict["created_at"] = datetime.fromisoformat(user_dict["created_at"])
                        if "last_login" in user_dict and isinstance(user_dict["last_login"], str):
                            user_dict["last_login"] = datetime.fromisoformat(user_dict["last_login"])
                        # ---------------------------------------------------------------------------------
                        
                        # Remove password hash
                        if "password_hash" in user_dict:
                            del user_dict["password_hash"]
                        users.append(user_dict)
                except json.JSONDecodeError as jde:
                    logger.error(f"list_users: JSON Decode Error for blob '{blob_full_name}': {jde}")
                except UnicodeDecodeError as ude:
                    logger.error(f"list_users: Unicode Decode Error for blob '{blob_full_name}': {ude}")
                except Exception as e:
                    logger.error(f"list_users: Error processing user blob '{blob_full_name}': {str(e)}", exc_info=True)
            
            logger.info(f"Successfully listed {len(users)} users.")
            return users
        except Exception as e:
            logger.error(f"Error listing users: {str(e)}", exc_info=True)
            return []
    
    @staticmethod
    def _hash_password(password: str) -> str:
        """
        Hash a password using bcrypt.
        """
        return pwd_context.hash(password)

    @staticmethod
    def _verify_password(plain_password: str, hashed_password: str) -> bool:
        """
        Verify a plain password against a hashed password using bcrypt.
        """
        return pwd_context.verify(plain_password, hashed_password)