from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field, EmailStr
from datetime import datetime # datetime 임포트

# --- 파일 관련 스키마 ---

class FileUploadResponse(BaseModel):
    """Response model for file upload"""
    blob_name: str = Field(..., description="The full path/name of the blob in storage (e.g., 'files/user-id/my_file.txt')")
    blob_url: str = Field(..., description="The URL to access the uploaded blob")
    filename: str = Field(..., description="The original filename provided by the user")
    content_type: str = Field(..., description="The MIME type of the uploaded file")
    size: int = Field(..., description="The size of the uploaded file in bytes")
    upload_time: datetime = Field(..., description="The exact time of upload in ISO 8601 format (UTC)")

class FileDeleteResponse(BaseModel):
    """Response model for file deletion"""
    success: bool = Field(..., description="Whether the deletion was successful")
    message: str = Field(..., description="A message describing the result of the deletion")

# FileDeleteRequest는 현재 엔드포인트 설계에 맞지 않으므로 주석 처리하거나 삭제
# @router.delete("/{blob_full_path:path}") 에서 경로 파라미터로 받으므로 Request Body는 필요 없습니다.
# class FileDeleteRequest(BaseModel):
#     """Request model for file deletion"""
#     blob_name: str


# --- 파일 목록 조회를 위한 새로운 스키마 ---
class FileListItem(BaseModel):
    """Model for a single file item in the history list"""
    file_id: str = Field(..., description="The unique ID of the file, typically its full blob path (e.g., 'files/user-id/my_document.txt')")
    file_name: str = Field(..., description="The original name of the file")
    file_size: int = Field(..., description="The size of the file in bytes")
    upload_time: Optional[datetime] = Field(None, description="The time the file was uploaded in ISO 8601 format (UTC)")
    metadata: Optional[Dict[str, Any]] = Field(None, description="Additional metadata associated with the file")

class FileListResponse(BaseModel):
    """Response model for file list"""
    files: List[FileListItem] = Field(..., description="The list of uploaded file items")

# --- 채팅 관련 스키마 ---

class ChatMessage(BaseModel):
    """Model for a chat message"""
    role: str = Field(..., description="The role of the message sender (user or assistant)")
    content: str = Field(..., description="The content of the message")
    timestamp: Optional[datetime] = Field(None, description="The timestamp of the message in ISO 8601 format (UTC)")
    execution_time: Optional[str] = Field(None, description="The execution time of the message (formatted string)")
    execution_time_seconds: Optional[float] = Field(None, description="The execution time in seconds")
    charts: Optional[List[Dict[str, Any]]] = Field(None, description="Any charts generated during analysis")

class ChatRequest(BaseModel):
    """Request model for chat"""
    message: str = Field(..., description="The user's message")
    file_blob_name: Optional[str] = Field(None, description="The full blob path of the file to analyze (e.g., 'files/user-id/timestamp_filename.ext')")
    history_id: Optional[str] = Field(None, description="The ID of the history to continue from")
    user_id: Optional[str] = Field(None, description="The ID of the user (deprecated, usually obtained from auth token)")

class ChatResponse(BaseModel):
    """Response model for chat"""
    message: str = Field(..., description="The assistant's response")
    execution_time: str = Field(..., description="The execution time of the request")
    execution_time_seconds: float = Field(..., description="The execution time in seconds")
    timestamp: datetime = Field(..., description="The timestamp of the response in ISO 8601 format (UTC)")
    history_id: str = Field(..., description="The ID of the conversation history")
    file_used: Optional[str] = Field(None, description="The full blob path of the file used for analysis (e.g., 'files/user-id/timestamp_filename.ext')")
    charts: Optional[List[Dict[str, Any]]] = Field(None, description="Any charts generated during analysis")

# --- 사용자 및 인증 관련 스키마 ---

class UserCreate(BaseModel):
    """Request model for user creation"""
    username: str = Field(..., description="The username for the new user")
    password: str = Field(..., description="The password for the new user")

class UserLogin(BaseModel):
    """Request model for user login"""
    username: str = Field(..., description="The username")
    password: str = Field(..., description="The password")

class UserResponse(BaseModel):
    """Response model for user information"""
    id: str = Field(..., description="The user ID")
    username: str = Field(..., description="The username")
    created_at: datetime = Field(..., description="The timestamp when the user was created in ISO 8601 format (UTC)")
    last_login: Optional[datetime] = Field(None, description="The timestamp of the last login in ISO 8601 format (UTC). Can be null if never logged in.") # last_login은 Optional일 수 있습니다.

class TokenResponse(BaseModel):
    """Response model for authentication token"""
    access_token: str = Field(..., description="The JWT access token")
    token_type: str = Field("bearer", description="The token type")
    user: UserResponse = Field(..., description="The user information")

# --- 대화 기록 관련 스키마 ---

class HistoryItem(BaseModel):
    """Model for a history item"""
    history_id: str = Field(..., description="The ID of the history item")
    timestamp: datetime = Field(..., description="The timestamp of the history item in ISO 8601 format (UTC)")
    messages: List[ChatMessage] = Field(..., description="The messages in the history")
    file_used: Optional[str] = Field(None, description="The full blob path of the file used for analysis in this history item (e.g., 'files/user-id/timestamp_filename.ext')")
    openai_file_id: Optional[str] = Field(None, description="The OpenAI File ID associated with the file used in this history (if any)")
    user_id: Optional[str] = Field(None, description="The ID of the user who owns this history")
    thread_id: Optional[str] = Field(None, description="The OpenAI Thread ID associated with this conversation history")

class HistoryListResponse(BaseModel):
    """Response model for history list"""
    history_items: List[HistoryItem] = Field(..., description="The list of history items")

class HistoryDeleteRequest(BaseModel):
    """Request model for history deletion"""
    history_id: str = Field(..., description="The ID of the history item to delete")

class HistoryDeleteResponse(BaseModel):
    """Response model for history deletion"""
    success: bool = Field(..., description="Whether the deletion was successful")
    message: str = Field(..., description="A message describing the result of the deletion")