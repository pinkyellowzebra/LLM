import os
import logging
from typing import Optional, List, Dict, Any
from openai import AzureOpenAI
from dotenv import load_dotenv # .env 파일에서 환경 변수를 로드하기 위함

# 로깅 설정
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# .env 파일 로드 (환경 변수가 파일에 정의되어 있다면)
load_dotenv()

# 환경 변수 로드
AZURE_OPENAI_API_KEY = os.getenv("AZURE_OPENAI_API_KEY")
AZURE_OPENAI_ENDPOINT = os.getenv("AZURE_OPENAI_ENDPOINT")
AZURE_OPENAI_API_VERSION = os.getenv("AZURE_OPENAI_API_VERSION") # 오타 수정: AZURE_OPENAI_API_VERSION
AZURE_OPENAI_DEPLOYMENT_NAME = os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME") # 이 값은 Assistant API에서는 직접적으로 사용되지 않을 수 있지만, 다른 모델 호출에 필요할 수 있으므로 포함

# --- 디버깅을 위해 추가적인 print 문을 넣어보는 것도 좋습니다 ---
print(f"Loaded AZURE_OPENAI_API_KEY: {'[SET]' if AZURE_OPENAI_API_KEY else '[NOT SET]'}")
print(f"Loaded AZURE_OPENAI_ENDPOINT: {'[SET]' if AZURE_OPENAI_ENDPOINT else '[NOT SET]'}")
print(f"Loaded AZURE_OPENAI_API_VERSION: {AZURE_OPENAI_API_VERSION}")
print(f"Loaded AZURE_OPENAI_DEPLOYMENT_NAME: {AZURE_OPENAI_DEPLOYMENT_NAME}")
# -----------------------------------------------------------

# 필수 환경 변수 확인
if not all([AZURE_OPENAI_API_KEY, AZURE_OPENAI_ENDPOINT, AZURE_OPENAI_API_VERSION]):
    raise ValueError(
        "필수 환경 변수(AZURE_OPENAI_API_KEY, AZURE_OPENAI_ENDPOINT, AZURE_OPENAI_API_VERSION)가 설정되지 않았습니다."
    )

async def create_openai_assistant(
    name: str = "Data Analysis Assistant",
    instructions: str = "You are a data analysis assistant. Analyze the provided data files and answer questions about them. Generate visualizations when appropriate.",
    model: str = AZURE_OPENAI_DEPLOYMENT_NAME, # 배포 이름이 모델 이름으로 사용됩니다.
    tools: Optional[List[Dict[str, Any]]] = None
) -> str:
    """
    Azure OpenAI Assistant를 생성하고 그 ID를 반환합니다.
    """
    try:
        client = AzureOpenAI(
            api_key=AZURE_OPENAI_API_KEY,
            api_version=AZURE_OPENAI_API_VERSION,
            azure_endpoint=AZURE_OPENAI_ENDPOINT
        )

        # 기본 도구 (코드 인터프리터) 설정. 필요에 따라 더 추가할 수 있습니다.
        if tools is None:
            tools = [{"type": "code_interpreter"}]

        logger.info(f"'{name}' Assistant 생성을 시작합니다...")
        logger.info(f"사용될 모델: {model}")

        assistant = client.beta.assistants.create(
            name=name,
            instructions=instructions,
            model=model,
            tools=tools
        )

        logger.info(f"Assistant가 성공적으로 생성되었습니다. ID: {assistant.id}")
        logger.info(f"Assistant 이름: {assistant.name}")
        logger.info(f"Assistant 지침: {assistant.instructions}")
        logger.info(f"Assistant 모델: {assistant.model}")
        
        return assistant.id

    except Exception as e:
        logger.error(f"Assistant 생성 중 오류 발생: {e}", exc_info=True)
        raise

async def main():
    """
    Assistant 생성 스크립트의 메인 함수.
    """
    # 여기에 생성하고 싶은 Assistant의 이름과 지침을 설정하세요.
    assistant_name = "Data Analysis Assistant"
    assistant_instructions = (
        "You are a data analysis assistant. Analyze the provided data files and answer questions about them. Generate visualizations when appropriate."
    )
    # 필요한 경우, 추가할 도구를 명시적으로 정의할 수 있습니다.
    # tools_to_add = [{"type": "code_interpreter"}, {"type": "retrieval"}] # 예시
    tools_for_assistant = [{"type": "code_interpreter"}] 
    
    try:
        assistant_id = await create_openai_assistant(
            name=assistant_name,
            instructions=assistant_instructions,
            tools=tools_for_assistant
        )
        print(f"\n--- 최종 생성된 Assistant ID ---")
        print(f"Assistant ID: {assistant_id}")
        print(f"이 ID를 환경 변수 'AZURE_OPENAI_ASSISTANT_ID'에 설정해주세요.")
    except Exception:
        print("\nAssistant 생성에 실패했습니다. 로그를 확인해주세요.")

if __name__ == "__main__":
    import asyncio
    asyncio.run(main())