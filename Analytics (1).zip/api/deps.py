import time
import logging
import asyncio
import psutil
from typing import Dict, Optional, List, Tuple, Any
from fastapi import HTTPException, Depends, Request, status
from fastapi.security import OAuth2PasswordBearer # OAuth2PasswordBearer 임포트

# 서비스 클래스 임포트
# UserService는 get_current_user_from_token을 위해 필요
from service.user_service import UserService 
# ChatService와 HistoryService는 의존성 주입을 위해 필요
from service.chat_service import ChatService
from service.history_service import HistoryService

# 설정 값 임포트
from config.settings import MAX_REQUESTS_PER_MINUTE

logger = logging.getLogger(__name__)

# --- OAuth2PasswordBearer 정의 (핵심 수정) ---
# 이 파일에서 다른 함수들이 사용할 수 있도록 여기에 정의합니다.
# tokenUrl은 main.py의 라우터 prefix와 user_routes.py의 라우터 prefix를 조합하여 정확하게 명시해야 합니다.
# (예: main.py: /api, user_routes.py: /users -> /api/users/login)
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/users/login") 

# --- ChatService 전역 인스턴스 관리 ---
_global_chat_service_instance: Optional[ChatService] = None

def set_global_chat_service_instance(instance: ChatService):
    """
    Sets the global ChatService instance.
    This function should be called ONLY ONCE during app startup (e.g., in lifespan event).
    """
    global _global_chat_service_instance
    if _global_chat_service_instance is not None:
        logger.warning(
            "Attempted to re-initialize _global_chat_service_instance. This should only happen once.",
            extra={"context": "ChatService Initialization"}
        )
    _global_chat_service_instance = instance
    logger.info("Global ChatService instance set.", extra={"instance_id": id(instance)})

def get_chat_service() -> ChatService:
    """
    FastAPI dependency that returns the globally managed ChatService instance.
    This function ensures that ChatService is initialized before use.
    Raises RuntimeError if ChatService is not initialized, indicating a misconfiguration.
    """
    if _global_chat_service_instance is None:
        logger.critical(
            "ChatService instance is not initialized. Application is likely misconfigured or failed to start correctly.",
            extra={"context": "ChatService Dependency"}
        )
        raise RuntimeError("ChatService not initialized. Application is not ready.")
    return _global_chat_service_instance

# --- HistoryService 의존성 함수 ---
# HistoryService는 ChatService에 의존하므로, ChatService를 먼저 주입받아 HistoryService를 생성합니다.
async def get_history_service(chat_service: ChatService = Depends(get_chat_service)) -> HistoryService:
    """
    FastAPI dependency that returns a HistoryService instance.
    It depends on get_chat_service to provide the necessary ChatService instance,
    ensuring HistoryService is properly initialized with its dependency.
    """
    logger.debug("Providing HistoryService instance.", extra={"chat_service_id": id(chat_service)})
    return HistoryService(chat_service=chat_service)

# --- RateLimiter 클래스 ---
class RateLimiter:
    """
    Advanced rate limiter to prevent server overload.
    Implements IP-based, user-based, and dynamic rate limiting based on server load.
    """
    def __init__(self, max_requests_per_minute: int = MAX_REQUESTS_PER_MINUTE):
        self.max_requests_per_minute = max_requests_per_minute
        self.ip_request_map: Dict[str, List[float]] = {}
        self.user_request_map: Dict[str, List[float]] = {}
        self.global_request_timestamps: List[float] = []
        self.backoff_periods: Dict[str, Tuple[float, int]] = {} # (end_time, duration)
        self._lock = asyncio.Lock()
        psutil.cpu_percent(interval=None) # Initialize cpu_percent to avoid 0.0 on first call
        logger.info(f"RateLimiter initialized with max_requests_per_minute: {self.max_requests_per_minute}")
    
    async def check(self, request: Request, user_id: Optional[str] = None):
        async with self._lock:
            current_time = time.time()
            client_ip = request.client.host if request and request.client else "unknown_ip"
            
            keys_to_check_for_backoff = ['global', client_ip]
            if user_id:
                keys_to_check_for_backoff.append(user_id)

            for key in keys_to_check_for_backoff:
                if key in self.backoff_periods:
                    backoff_end_time, retry_duration = self.backoff_periods[key]
                    if current_time < backoff_end_time:
                        retry_after = int(backoff_end_time - current_time)
                        
                        detail_message = "Too many requests. Please try again later."
                        if key == "global":
                            detail_message = f"Server is experiencing high load. Please try again after {retry_after} seconds."
                            logger.warning(f"Global backoff active. Rejecting request. "
                                           f"End time: {time.ctime(backoff_end_time)}, Retry-After: {retry_after}s.",
                                           extra={"ip": client_ip, "user_id": user_id})
                        elif key == client_ip:
                            detail_message = f"Too many requests from your IP ({client_ip}). Please try again after {retry_after} seconds."
                            logger.warning(f"IP backoff active. Rejecting request. "
                                           f"IP: {client_ip}, End time: {time.ctime(backoff_end_time)}, Retry-After: {retry_after}s.",
                                           extra={"ip": client_ip, "user_id": user_id})
                        else: # user_id
                            detail_message = f"Too many requests from your account ({user_id}). Please try again after {retry_after} seconds."
                            logger.warning(f"User backoff active. Rejecting request. "
                                           f"User: {user_id}, End time: {time.ctime(backoff_end_time)}, Retry-After: {retry_after}s.",
                                           extra={"ip": client_ip, "user_id": user_id})

                        raise HTTPException(
                            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                            detail=detail_message,
                            headers={"Retry-After": str(retry_after)}
                        )
            
            # 오래된 타임스탬프 정리
            one_minute_ago = current_time - 60
            self.global_request_timestamps = [ts for ts in self.global_request_timestamps if ts > one_minute_ago]
            if client_ip in self.ip_request_map:
                self.ip_request_map[client_ip] = [ts for ts in self.ip_request_map[client_ip] if ts > one_minute_ago]
            if user_id and user_id in self.user_request_map:
                self.user_request_map[user_id] = [ts for ts in self.user_request_map[user_id] if ts > one_minute_ago]

            # 만료된 백오프 기간 제거
            self.backoff_periods = {k: v for k, v in self.backoff_periods.items() if current_time < v[0]}

            dynamic_limit = self._get_dynamic_rate_limit()
            
            # IP 및 사용자별 제한은 전체 동적 제한의 50%로 설정 (조정 가능)
            ip_limit = max(1, int(dynamic_limit * 0.5))
            user_limit = max(1, int(dynamic_limit * 0.5))

            global_requests = len(self.global_request_timestamps)
            if global_requests >= dynamic_limit:
                retry_after_global = self._apply_backoff("global", current_time)
                logger.warning(f"Global rate limit exceeded: {global_requests}/{dynamic_limit} requests in the last minute. Applying backoff.",
                               extra={"ip": client_ip, "user_id": user_id, "retry_after": retry_after_global})
                raise HTTPException(
                    status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                    detail=f"Server is experiencing high load. Please try again after {retry_after_global} seconds.",
                    headers={"Retry-After": str(retry_after_global)}
                )
            
            ip_requests = len(self.ip_request_map.get(client_ip, []))
            if ip_requests >= ip_limit:
                retry_after_ip = self._apply_backoff(client_ip, current_time)
                logger.warning(f"IP rate limit exceeded for {client_ip}: {ip_requests}/{ip_limit} requests in the last minute. Applying backoff.",
                               extra={"ip": client_ip, "user_id": user_id, "retry_after": retry_after_ip})
                raise HTTPException(
                    status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                    detail=f"Too many requests from your IP ({client_ip}). Please try again after {retry_after_ip} seconds.",
                    headers={"Retry-After": str(retry_after_ip)}
                )
            
            user_requests = len(self.user_request_map.get(user_id, [])) if user_id else 0
            if user_id and user_requests >= user_limit:
                retry_after_user = self._apply_backoff(user_id, current_time)
                logger.warning(f"User rate limit exceeded for {user_id}: {user_requests}/{user_limit} requests in the last minute. Applying backoff.",
                               extra={"ip": client_ip, "user_id": user_id, "retry_after": retry_after_user})
                raise HTTPException(
                    status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                    detail=f"Too many requests from your account ({user_id}). Please try again after {retry_after_user} seconds.",
                    headers={"Retry-After": str(retry_after_user)}
                )
            
            # 요청 허용 시 타임스탬프 추가
            self.global_request_timestamps.append(current_time)
            if client_ip not in self.ip_request_map:
                self.ip_request_map[client_ip] = []
            self.ip_request_map[client_ip].append(current_time)
            if user_id:
                if user_id not in self.user_request_map:
                    self.user_request_map[user_id] = []
                self.user_request_map[user_id].append(current_time)
            
            logger.debug(f"Request allowed. IP: {client_ip}, User: {user_id}. "
                         f"Current counts: Global={global_requests+1}/{dynamic_limit}, IP={ip_requests+1}/{ip_limit}, User={user_requests+1}/{user_limit}",
                         extra={"ip": client_ip, "user_id": user_id})

    def _get_dynamic_rate_limit(self) -> int:
        try:
            # CPU 사용량 가져오기 (논블로킹)
            cpu_percent = psutil.cpu_percent(interval=None) 
            # 메모리 사용량 가져오기
            memory = psutil.virtual_memory()
            memory_percent = memory.percent
            
            # CPU 사용량이 높을수록, 제한 계수 낮춤
            # 예: 0% -> 1.0, 100% -> 0.3 (1.0 - 0.7)
            cpu_factor = max(0.2, 1.0 - (cpu_percent / 100) * 0.7) 
            # 메모리 사용량이 높을수록, 제한 계수 낮춤
            memory_factor = max(0.2, 1.0 - (memory_percent / 100) * 0.7)
            
            # 두 요소 중 더 제한적인 것을 선택
            load_factor = min(cpu_factor, memory_factor) 
            
            # 최소 요청 수 보장 (예: 서버 부하가 아무리 높아도 최소 5개 요청은 처리)
            dynamic_limit = max(5, int(self.max_requests_per_minute * load_factor))
            
            logger.debug(f"Dynamic rate limit calculated: {dynamic_limit} (CPU: {cpu_percent:.1f}%, Mem: {memory_percent:.1f}%, Load Factor: {load_factor:.2f})")
            return dynamic_limit
        
        except Exception as e:
            logger.error(f"Error calculating dynamic rate limit: {str(e)}", exc_info=True,
                         extra={"context": "Dynamic Rate Limit Calculation"})
            # 오류 발생 시 기본 제한으로 폴백
            return self.max_requests_per_minute
    
    def _apply_backoff(self, key: str, current_time: float) -> int:
        """
        Applies an exponential backoff for a given key and returns the retry duration.
        """
        previous_retry_duration = 0
        if key in self.backoff_periods:
            if self.backoff_periods[key][0] > current_time: # 아직 백오프 기간 중이면
                previous_retry_duration = self.backoff_periods[key][1]
        
        # 이전 백오프 시간의 두 배 또는 최소 60초 (최대 1800초 = 30분)
        new_retry_duration = max(60, previous_retry_duration * 2) 
        new_retry_duration = min(1800, new_retry_duration) 
        
        self.backoff_periods[key] = (current_time + new_retry_duration, new_retry_duration)
        logger.info(f"Applied backoff for '{key}': {new_retry_duration} seconds (until {time.ctime(current_time + new_retry_duration)})",
                    extra={"key": key, "duration": new_retry_duration})
        return new_retry_duration

_custom_rate_limiter = RateLimiter()

# --- Dependency functions for FastAPI ---

async def get_current_user(token: str = Depends(oauth2_scheme)):
    """
    Dependency to get the current authenticated user.
    Authenticates user via OAuth2 bearer token.
    Raises HTTPException 401 if authentication fails.
    """
    # UserService.get_current_user_from_token 메서드 호출
    return await UserService.get_current_user_from_token(token) 

async def get_optional_user(token: Optional[str] = Depends(oauth2_scheme)) -> Optional[Dict[str, Any]]:
    """
    Dependency to get the current user if authenticated, or None if not.
    """
    if not token:
        logger.debug("No token provided for optional user authentication.")
        return None
    try:
        # UserService.get_current_user_from_token 메서드 호출
        user = await UserService.get_current_user_from_token(token)
        logger.debug(f"Optional user authenticated: {user.get('id')}", extra={"user_id": user.get('id')})
        return user
    except HTTPException as e:
        # 401 또는 403 오류는 인증 실패로 간주하고 None 반환
        if e.status_code in [status.HTTP_401_UNAUTHORIZED, status.HTTP_403_FORBIDDEN]:
            logger.warning(f"Optional user authentication failed (status {e.status_code}): {e.detail}. Proceeding as unauthenticated.",
                           extra={"detail": e.detail})
            return None
        # 그 외 HTTPException은 다시 발생
        logger.error(f"HTTPException during optional user authentication: {e.detail} (status {e.status_code})", exc_info=True)
        raise
    except Exception as e:
        logger.error(f"Unexpected error getting optional user: {str(e)}", exc_info=True,
                     extra={"context": "Optional User Dependency"})
        return None

# --- get_rate_limiter 함수 (최종 수정) ---
async def get_rate_limiter(request: Request) -> RateLimiter:
    """
    Dependency to get the custom rate limiter and perform the check.
    For public routes (register, login), user authentication is optional.
    For protected routes, user authentication is required before this dependency.
    """
    user_id: Optional[str] = None
    
    # 요청 경로가 '/api/users/register' 또는 '/api/users/login'인지 확인
    # router = APIRouter(prefix="/users", tags=["Users"]) and main.py: app.include_router(user_routes.router, prefix="/api")
    # 
    # 따라서, `/api/users/register` 와 `/api/users/login`이 올바른 경로입니다.
    is_public_auth_route = request.url.path in ["/api/users/register", "/api/users/login"]

    if not is_public_auth_route:
        # 공개 인증 라우트가 아니면, Authorization 헤더에서 토큰을 추출하여 user_info를 가져옵니다.
        # 이 과정에서 get_optional_user를 직접 호출하여 토큰 유효성 검사를 수행합니다.
        try:
            auth_header = request.headers.get("Authorization")
            token = auth_header.replace("Bearer ", "") if auth_header and auth_header.startswith("Bearer ") else None
            
            # get_optional_user 의존성 함수를 사용하여 사용자 정보를 가져옵니다.
            # 의존성 주입은 요청 컨텍스트에서 작동하므로, 여기서 직접 호출하는 것은 의존성을 '수동으로' 실행하는 것과 같습니다.
            # FastAPI의 Depends를 통해 주입되는 방식으로 라우트 핸들러에서 사용하지 않는다면, 
            # 여기서 토큰을 디코딩하는 로직을 직접 구현하거나, UserService.get_current_user_from_token을 호출하는 것이 더 나을 수 있습니다.
            # 하지만 현재 구조에서는 get_optional_user가 HTTPException을 적절히 처리하므로 그대로 사용합니다.
            user_info = await get_optional_user(token=token) # get_optional_user를 직접 호출
            if user_info:
                user_id = user_info.get("id")
            logger.debug(f"Rate Limiter: User info obtained for non-public route. User ID: {user_id}")
        except HTTPException as e:
            # get_optional_user 내부에서 401/403은 처리되므로 여기서는 추가 예외 처리 불필요
            logger.warning(f"Rate Limiter: HTTPException during user lookup for non-public route: {e.detail}")
            pass # 토큰이 없거나 유효하지 않아도 rate limit은 적용되어야 합니다.
        except Exception as e:
            logger.error(f"Rate Limiter: Unexpected error during user lookup for non-public route: {e}", exc_info=True)
            pass # 오류 발생 시에도 사용자 ID 없이 rate limit 적용

    await _custom_rate_limiter.check(
        request=request,
        user_id=user_id # 얻어온 user_id를 전달
    )
    return _custom_rate_limiter