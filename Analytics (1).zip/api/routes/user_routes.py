import logging
from typing import List, Dict # 필요한 임포트 유지
from fastapi import APIRouter, Depends, HTTPException, status, Request # Request 임포트
from fastapi.security import OAuth2PasswordRequestForm

# models/schemas.py에서 필요한 모든 Pydantic 모델 임포트
from models.schemas import UserCreate, UserResponse, TokenResponse, UserLogin # <-- UserLogin이 여기에 있어야 합니다!
from service.user_service import UserService

# RateLimiter 클래스가 api.deps에 정의되어 있고 get_rate_limiter에 의해 반환된다고 가정하고 임포트합니다.
from api.deps import get_rate_limiter, get_current_user, RateLimiter # <-- RateLimiter 클래스 임포트

logger = logging.getLogger(__name__)

# 라우터에 "/users" prefix를 명시적으로 추가. 
# main.py에서는 이 라우터를 app.include_router(user_routes.router, prefix="/api", ...) 형태로 포함해야 합니다.
# 이렇게 하면 최종 URL은 /api/users/... 가 됩니다.
router = APIRouter(tags=["Users"]) 

@router.post("/register", response_model=UserResponse)
async def register_user(
    user_data: UserCreate,
    request: Request, # Request 객체 주입
    rate_limiter: RateLimiter = Depends(get_rate_limiter) # RateLimiter 타입 힌트 적용
):
    """
    Register a new user
    """
    logger.info(f"Registering user: {user_data.username}")
    await rate_limiter.check(request=request) # request 인자 전달
    try:
        new_user = await UserService.register_user(
            user_data=user_data
        )
        return new_user
    except HTTPException as e:
        raise e
    except Exception as e:
        logger.error(f"Error during user registration: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="An unexpected error occurred during registration. Please try again later."
        )

@router.post("/login", response_model=TokenResponse)
async def login_user(
    request: Request, # Request 객체 주입
    form_data: OAuth2PasswordRequestForm = Depends(),
    rate_limiter: RateLimiter = Depends(get_rate_limiter) # RateLimiter 타입 힌트 적용
):
    """
    Authenticate a user and return a JWT token
    """
    await rate_limiter.check(request) # request 인자 전달
    
    # OAuth2PasswordRequestForm에서 받은 데이터를 UserLogin Pydantic 모델로 변환
    login_data_model = UserLogin(username=form_data.username, password=form_data.password)

    # UserService.login_user 함수에 UserLogin Pydantic 모델 인스턴스를 전달합니다.
    return await UserService.login_user(login_data_model)

@router.get("/me", response_model=UserResponse)
async def get_current_user_info(
    request: Request, # Request 객체 추가!
    current_user: dict = Depends(get_current_user),
    rate_limiter: RateLimiter = Depends(get_rate_limiter) # RateLimiter 타입 힌트 적용
):
    """
    Get information about the current authenticated user
    """
    await rate_limiter.check(request) # request 인자 전달!
    # current_user는 dict 타입이므로, UserResponse 모델에 맞게 명시적으로 전달
    return UserResponse(
        id=current_user["id"],
        username=current_user["username"],
        created_at=current_user["created_at"],
        last_login=current_user["last_login"]
    )

@router.get("/list", response_model=List[UserResponse])
async def list_users(
    request: Request, # Request 객체 추가!
    current_user: dict = Depends(get_current_user),
    rate_limiter: RateLimiter = Depends(get_rate_limiter) # RateLimiter 타입 힌트 적용
):
    """
    List all users (admin only)
    """
    # TODO: 관리자 권한 확인 로직 추가 필요 (예: if not current_user.get("is_admin"): ...)
    await rate_limiter.check(request) # request 인자 전달!
    return await UserService.list_users()