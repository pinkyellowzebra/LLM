import logging
from fastapi import APIRouter, Request, Depends, HTTPException, status
from fastapi.responses import JSONResponse

from models.schemas import ChatRequest, ChatResponse, HistoryListResponse, HistoryItem, HistoryDeleteRequest, HistoryDeleteResponse
from service.chat_service import ChatService
from service.history_service import HistoryService # This import is necessary here
from api.deps import get_rate_limiter, get_optional_user, get_chat_service, get_history_service

router = APIRouter(prefix="/api/chat", tags=["chat"])
logger = logging.getLogger(__name__)

@router.post("/message", response_model=ChatResponse)
async def process_chat_message(
    chat_request_body: ChatRequest, 
    http_request: Request,
    chat_service: ChatService = Depends(get_chat_service),
    history_service: HistoryService = Depends(get_history_service), # Inject HistoryService here
    rate_limiter = Depends(get_rate_limiter),
    current_user: dict = Depends(get_optional_user)
):
    """
    Process a chat message using Azure OpenAI's Assistant API.

    - **message**: The user's message
    - **file_blob_name**: (Optional) The blob name of the file to analyze
    - **history_id**: (Optional) The ID of the history to continue from

    Returns the assistant's response, execution time, and other information.
    """
    try:
        await rate_limiter.check(http_request, user_id=current_user["id"] if current_user else None)

        user_id = current_user["id"] if current_user else None
        logger.info(f"Processing chat message with user_id: {user_id}")

        # Pass the history_service instance to chat_service.process_chat
        result = await chat_service.process_chat(
            message=chat_request_body.message,
            file_blob_name=chat_request_body.file_blob_name,
            history_id=chat_request_body.history_id,
            user_id=user_id,
            history_service=history_service # This is the key change for dependency injection
        )
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error processing chat message: {str(e)}", exc_info=True)
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Error processing chat message: {str(e)}")


@router.get("/history", response_model=HistoryListResponse)
async def list_history(
    request: Request,
    history_service: HistoryService = Depends(get_history_service), # Inject HistoryService here
    rate_limiter = Depends(get_rate_limiter),
    current_user: dict = Depends(get_optional_user)
):
    """
    List all conversation history.

    Returns a list of history items.
    """
    try:
        await rate_limiter.check(request, user_id=current_user["id"] if current_user else None)

        user_id = current_user["id"] if current_user else None
        # Use the injected history_service instance
        result = await history_service.list_history(user_id) 
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error listing history: {str(e)}", exc_info=True)
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Error listing history: {str(e)}")


@router.get("/history/{history_id}", response_model=HistoryItem)
async def get_history(
    history_id: str,
    request: Request,
    history_service: HistoryService = Depends(get_history_service),
    rate_limiter = Depends(get_rate_limiter),
    current_user: dict = Depends(get_optional_user)
):
    """
    Get a specific history item by ID.

    - **history_id**: The ID of the history item to get

    Returns the history item.
    """
    try:
        await rate_limiter.check(request, user_id=current_user["id"] if current_user else None)

        user_id = current_user["id"] if current_user else None
        # Use the injected history_service instance
        result = await history_service.get_history(history_id, user_id)

        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting history {history_id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Error getting history: {str(e)}")


@router.post("/history/delete", response_model=HistoryDeleteResponse)
async def delete_history(
    request: Request,
    req_body: HistoryDeleteRequest,
    rate_limiter = Depends(get_rate_limiter),
    current_user: dict = Depends(get_optional_user),
    chat_service: ChatService = Depends(get_chat_service), # Still needed if delete_history in HistoryService needs chat_service
    history_service: HistoryService = Depends(get_history_service)
):
    """
    Delete a specific history item by ID.
    This will also attempt to delete associated OpenAI Threads and Files.

    - **history_id**: The ID of the history item to delete

    Returns a success flag and message.
    """
    try:
        await rate_limiter.check(request, user_id=current_user["id"] if current_user else None)

        user_id = current_user["id"] if current_user else None

        # HistoryService.delete_history now takes chat_service as an argument for deleting OpenAI resources.
        # This is where the dependency injection from the API layer flows down to the service layer.
        success = await history_service.delete_history(
            history_id=req_body.history_id,
            user_id=user_id,
            chat_service=chat_service # Pass chat_service here
        ) 

        # If no HTTPException was raised by history_service.delete_history, it was successful.
        return HistoryDeleteResponse(
            success=success,
            message="History and associated resources deleted successfully."
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting history {req_body.history_id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Error deleting history: {str(e)}")