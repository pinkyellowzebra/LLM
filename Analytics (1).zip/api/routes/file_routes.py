import logging
import os # 'os' 모듈 임포트 추가 (파일 이름 추출을 위해 여전히 필요할 수 있음)
from typing import Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, status, UploadFile, File

from service.file_service import FileService # FileService 임포트
# from utils.blob_utils import blob_storage_manager # 이제 FileService 내에서 처리하므로 직접 임포트할 필요 없음
# from config.settings import BLOB_FOLDER_FILES # 이제 FileService 내에서 처리하므로 직접 임포트할 필요 없음
from api.deps import get_current_user, get_rate_limiter
from models.schemas import FileUploadResponse, FileListResponse, FileDeleteResponse

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/files", tags=["Files"])

@router.post("/upload", response_model=FileUploadResponse)
async def upload_file_endpoint(
    file: UploadFile = File(...),
    user: Dict = Depends(get_current_user),
    rate_limiter=Depends(get_rate_limiter)
):
    """
    사용자가 파일을 업로드하고, 업로드된 파일 정보를 반환합니다.
    """
    user_id = user.get("id")
    if not user_id:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="인증된 사용자만 파일을 업로드할 수 있습니다."
        )

    logger.info(f"사용자 {user_id}가 파일 업로드 요청: {file.filename}")
    try:
        # FileService의 static 메서드 호출 (또는 주입된 인스턴스 메서드)
        file_info = await FileService.upload_file(file=file, user_id=user_id)
        # FileService에서 이미 HTTPException을 처리하므로, 여기서는 별도의 'if not file_info:' 확인이 불필요합니다.
        return file_info
    except HTTPException as e:
        # FileService에서 발생한 HTTPException은 그대로 다시 발생시킵니다.
        raise e
    except Exception as e:
        logger.error(f"파일 업로드 중 예기치 않은 오류 발생: {e}", exc_info=True, extra={"user_id": user_id})
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"파일 업로드 중 서버 오류 발생: {str(e)}"
        )

@router.get("/list", response_model=FileListResponse)
async def list_files_endpoint(
    user: Dict = Depends(get_current_user),
    rate_limiter=Depends(get_rate_limiter)
):
    """
    사용자가 업로드한 파일 목록을 조회합니다.
    """
    user_id = user.get("id")
    if not user_id:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="인증된 사용자만 파일 목록을 조회할 수 있습니다."
        )

    logger.info(f"사용자 {user_id}의 파일 목록 조회 요청")
    try:
        # FileService의 list_files 메서드를 호출하여 파일 목록을 가져옵니다.
        # FileService.list_files는 이미 FileListResponse에 적합한 형식으로 데이터를 반환할 것입니다.
        files_data = await FileService.list_files(user_id=user_id)
        
        # FileService에서 이미 포맷된 리스트를 반환하므로,
        # 여기서는 바로 FileListResponse 모델에 넣어 반환하면 됩니다.
        return FileListResponse(files=files_data)
    except HTTPException as e:
        # FileService에서 발생한 HTTPException은 그대로 다시 발생시킵니다.
        raise e
    except Exception as e:
        logger.error(f"파일 목록 조회 중 예기치 않은 오류 발생: {e}", exc_info=True, extra={"user_id": user_id})
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"파일 목록 조회 중 서버 오류 발생: {str(e)}"
        )

@router.delete("/{blob_full_path:path}", response_model=FileDeleteResponse)
async def delete_file_endpoint(
    blob_full_path: str,
    user: Dict = Depends(get_current_user),
    rate_limiter=Depends(get_rate_limiter)
):
    """
    지정된 ID의 파일을 삭제합니다.
    여기서 file_id는 Azure Blob Storage 내의 파일의 전체 경로(예: files/user-id/my_document.txt)입니다.
    """
    user_id = user.get("id")
    if not user_id:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="인증된 사용자만 파일을 삭제할 수 있습니다."
        )

    logger.info(f"사용자 {user_id}가 파일 {blob_full_path} 삭제 요청")
    try:
        # FileService의 static 메서드 호출 (또는 주입된 인스턴스 메서드)
        response = await FileService.delete_file(blob_full_path=blob_full_path, user_id=user_id)
        return response
    except HTTPException as e:
        # FileService에서 발생한 HTTPException은 그대로 다시 발생시킵니다.
        raise e
    except Exception as e:
        logger.error(f"파일 {blob_full_path} 삭제 중 예기치 않은 오류 발생: {e}", exc_info=True, extra={"user_id": user_id})
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"파일 삭제 중 서버 오류 발생: {str(e)}"
        )