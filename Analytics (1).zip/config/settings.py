import os
from typing import Optional
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Azure Blob Storage settings
AZURE_STORAGE_CONNECTION_STRING = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
AZURE_BLOB_CONTAINER_NAME = os.getenv("AZURE_BLOB_CONTAINER_NAME", "h-ai-platform-dev")

# Blob storage folder paths
BLOB_FOLDER_FILES = os.getenv("BLOB_FOLDER_FILES", "analyticsfiles")
BLOB_FOLDER_HISTORY = os.getenv("BLOB_FOLDER_HISTORY", "analyticshistory")
BLOB_FOLDER_USERS = os.getenv("BLOB_FOLDER_USERS", "analyticsusers")

# Azure OpenAI settings
AZURE_OPENAI_API_KEY = os.getenv("AZURE_OPENAI_API_KEY")
AZURE_OPENAI_ENDPOINT = os.getenv("AZURE_OPENAI_ENDPOINT")
AZURE_OPENAI_API_VERSION = os.getenv("AZURE_OPENAI_API_VERSION")
AZURE_OPENAI_DEPLOYMENT_NAME = os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME")
AZURE_OPENAI_ASSISTANT_ID: Optional[str] = os.getenv("AZURE_OPENAI_ASSISTANT_ID", None)

# File upload settings
MAX_FILE_SIZE = 50 * 1024 * 1024  # 50MB
ALLOWED_EXTENSIONS = [".txt", ".xlsx"]

# Server settings
SERVER_HOST = os.getenv("SERVER_HOST", "127.0.0.1")  # Use localhost instead of 0.0.0.0
SERVER_PORT = int(os.getenv("SERVER_PORT", "8000"))
DEBUG_MODE = True  # 디버그 모드 강제 활성화

# Rate limiting settings
MAX_REQUESTS_PER_MINUTE = int(os.getenv("MAX_REQUESTS_PER_MINUTE", "60"))

# JWT settings
JWT_SECRET_KEY = os.getenv("JWT_SECRET_KEY", "your-secret-key-for-jwt-please-change-in-production")
JWT_ALGORITHM = os.getenv("JWT_ALGORITHM", "HS256")
JWT_EXPIRATION_MINUTES = int(os.getenv("JWT_EXPIRATION_MINUTES", "60"))  # 1 hour
