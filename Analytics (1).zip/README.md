# Azure Blob Storage Troubleshooting Guide

This guide helps resolve the 401 Unauthorized error when uploading files to Azure Blob Storage through the Swagger UI.

## Problem

When trying to upload files through the Swagger UI, you're encountering a 401 Unauthorized error:

```
Undocumented
Error: Unauthorized
```

## Solution

The issue is likely related to Azure Blob Storage authentication or permissions. The following changes have been made to fix the problem:

1. Enhanced the `BlobStorageManager` class to:
   - Provide better error logging
   - Create the container with public access if it doesn't exist
   - Check container properties before upload

2. Improved error handling in the file upload endpoint to:
   - Provide more detailed error messages
   - Specifically catch and report authentication errors

3. Enhanced CORS configuration to ensure proper cross-origin requests

## How to Test the Fix

### 1. Test Azure Blob Storage Connection

Run the test script to verify your Azure Blob Storage connection:

```bash
python test_blob_connection.py
```

This script will:
- Test the connection to Azure Blob Storage
- Verify container access
- Create a test blob and delete it
- Provide detailed logs of any issues

### 2. Run the Application with Enhanced Debugging

Use the debug script to run the application with detailed Azure Storage logging:

```bash
python run_with_debug.py
```

This will:
- Enable detailed logging for Azure Storage operations
- Write logs to both console and `app_debug.log` file
- Show environment configuration (without sensitive data)

### 3. Check for Common Issues

If you're still experiencing issues, check the following:

#### Azure Storage Account Configuration

1. **Network Access**: Ensure your Azure Storage account allows access from your network
   - Check firewall settings in the Azure Portal
   - Temporarily allow access from all networks for testing

2. **CORS Settings**: Configure CORS in your Azure Storage account
   - In Azure Portal, go to your storage account → Settings → Resource sharing (CORS)
   - Add a rule with:
     - Allowed origins: * (or your specific origin)
     - Allowed methods: GET, PUT, POST, DELETE, OPTIONS
     - Allowed headers: *
     - Exposed headers: *
     - Max age: 86400

3. **Container Permissions**: Check container access level
   - In Azure Portal, go to your storage account → Containers
   - Select your container and check its access level
   - For testing, you can set it to "Container (anonymous read access for containers and blobs)"

#### Connection String

Ensure your connection string in `.env` file is:
- Current and not expired
- Has the correct permissions (read/write)
- Properly formatted

Example of a valid connection string:
```
DefaultEndpointsProtocol=https;AccountName=youraccount;AccountKey=yourkey;EndpointSuffix=core.windows.net
```

## Additional Debugging

If you need more information, check the following log files:
- `app_debug.log`: Detailed application logs
- `app_log.txt`: General application logs

## Contact Support

If you continue to experience issues after trying these solutions, please contact Azure support with:
1. The exact error message
2. Logs from `test_blob_connection.py`
3. Your storage account name (not the key)
